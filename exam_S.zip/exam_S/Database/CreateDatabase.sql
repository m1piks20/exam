USE master;
GO
IF DB_ID(N'BicycleDriveDb') IS NOT NULL
BEGIN
    ALTER DATABASE BicycleDriveDb SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE BicycleDriveDb;
END
GO
CREATE DATABASE BicycleDriveDb;
GO
USE BicycleDriveDb;
GO

CREATE TABLE Role (
    RoleId INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE AppUser (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    RoleId INT NOT NULL,
    FullName NVARCHAR(150) NOT NULL,
    Login NVARCHAR(100) NOT NULL UNIQUE,
    PasswordText NVARCHAR(100) NOT NULL,
    CONSTRAINT FK_AppUser_Role FOREIGN KEY (RoleId) REFERENCES Role(RoleId)
);

CREATE TABLE Category (
    CategoryId INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(120) NOT NULL UNIQUE
);

CREATE TABLE Manufacturer (
    ManufacturerId INT IDENTITY(1,1) PRIMARY KEY,
    ManufacturerName NVARCHAR(120) NOT NULL UNIQUE
);

CREATE TABLE Supplier (
    SupplierId INT IDENTITY(1,1) PRIMARY KEY,
    SupplierName NVARCHAR(120) NOT NULL UNIQUE
);

CREATE TABLE Unit (
    UnitId INT IDENTITY(1,1) PRIMARY KEY,
    UnitName NVARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE Item (
    ItemId INT IDENTITY(1,1) PRIMARY KEY,
    Article NVARCHAR(30) NOT NULL UNIQUE,
    ItemName NVARCHAR(250) NOT NULL,
    CategoryId INT NOT NULL,
    Description NVARCHAR(MAX) NULL,
    ManufacturerId INT NOT NULL,
    SupplierId INT NOT NULL,
    UnitId INT NOT NULL,
    Price DECIMAL(12,2) NOT NULL CHECK (Price >= 0),
    StockQuantity INT NOT NULL CHECK (StockQuantity >= 0),
    DiscountPercent DECIMAL(5,2) NOT NULL DEFAULT 0 CHECK (DiscountPercent >= 0 AND DiscountPercent <= 100),
    ImagePath NVARCHAR(260) NULL,
    CONSTRAINT FK_Item_Category FOREIGN KEY (CategoryId) REFERENCES Category(CategoryId),
    CONSTRAINT FK_Item_Manufacturer FOREIGN KEY (ManufacturerId) REFERENCES Manufacturer(ManufacturerId),
    CONSTRAINT FK_Item_Supplier FOREIGN KEY (SupplierId) REFERENCES Supplier(SupplierId),
    CONSTRAINT FK_Item_Unit FOREIGN KEY (UnitId) REFERENCES Unit(UnitId)
);

CREATE TABLE PickupPoint (
    PickupPointId INT IDENTITY(1,1) PRIMARY KEY,
    AddressText NVARCHAR(250) NOT NULL UNIQUE
);

CREATE TABLE OrderStatus (
    OrderStatusId INT IDENTITY(1,1) PRIMARY KEY,
    StatusName NVARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE OrderHeader (
    OrderId INT IDENTITY(1,1) PRIMARY KEY,
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NULL,
    PickupPointId INT NOT NULL,
    CustomerName NVARCHAR(150) NULL,
    ReceiveCode INT NOT NULL,
    OrderStatusId INT NOT NULL,
    CONSTRAINT FK_OrderHeader_PickupPoint FOREIGN KEY (PickupPointId) REFERENCES PickupPoint(PickupPointId),
    CONSTRAINT FK_OrderHeader_OrderStatus FOREIGN KEY (OrderStatusId) REFERENCES OrderStatus(OrderStatusId)
);

CREATE TABLE OrderItem (
    OrderItemId INT IDENTITY(1,1) PRIMARY KEY,
    OrderId INT NOT NULL,
    ItemId INT NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    CONSTRAINT FK_OrderItem_OrderHeader FOREIGN KEY (OrderId) REFERENCES OrderHeader(OrderId) ON DELETE CASCADE,
    CONSTRAINT FK_OrderItem_Item FOREIGN KEY (ItemId) REFERENCES Item(ItemId),
    CONSTRAINT UQ_OrderItem_Order_Item UNIQUE (OrderId, ItemId)
);
GO
INSERT INTO Role(RoleName) VALUES (N'Авторизированный клиент');
INSERT INTO Role(RoleName) VALUES (N'Администратор');
INSERT INTO Role(RoleName) VALUES (N'Менеджер');
INSERT INTO Category(CategoryName) VALUES (N'Велосипед взрослый горный');
INSERT INTO Category(CategoryName) VALUES (N'Велосипед городской взрослый');
INSERT INTO Category(CategoryName) VALUES (N'Велосипед городской подростковый');
INSERT INTO Category(CategoryName) VALUES (N'Велосипед детский горный');
INSERT INTO Category(CategoryName) VALUES (N'Велосипед детский городской');
INSERT INTO Manufacturer(ManufacturerName) VALUES (N'
Aero');
INSERT INTO Manufacturer(ManufacturerName) VALUES (N'Fizard');
INSERT INTO Manufacturer(ManufacturerName) VALUES (N'NEXT');
INSERT INTO Manufacturer(ManufacturerName) VALUES (N'Shimano');
INSERT INTO Manufacturer(ManufacturerName) VALUES (N'Skill bike');
INSERT INTO Manufacturer(ManufacturerName) VALUES (N'Slash');
INSERT INTO Manufacturer(ManufacturerName) VALUES (N'kari');
INSERT INTO Supplier(SupplierName) VALUES (N'kari');
INSERT INTO Supplier(SupplierName) VALUES (N'ВелоСтрана');
INSERT INTO Supplier(SupplierName) VALUES (N'ПерспективаГрупп');
INSERT INTO Supplier(SupplierName) VALUES (N'Скилс');
INSERT INTO Supplier(SupplierName) VALUES (N'ЯндексМаркет');
INSERT INTO Unit(UnitName) VALUES (N'шт.');
INSERT INTO OrderStatus(StatusName) VALUES (N'Завершен');
INSERT INTO OrderStatus(StatusName) VALUES (N'Новый');
INSERT INTO PickupPoint(AddressText) VALUES (N'420151, г. Лесной, ул. Вишневая, 32');
INSERT INTO PickupPoint(AddressText) VALUES (N'125061, г. Лесной, ул. Подгорная, 8');
INSERT INTO PickupPoint(AddressText) VALUES (N'630370, г. Лесной, ул. Шоссейная, 24');
INSERT INTO PickupPoint(AddressText) VALUES (N'400562, г. Лесной, ул. Зеленая, 32');
INSERT INTO PickupPoint(AddressText) VALUES (N'614510, г. Лесной, ул. Маяковского, 47');
INSERT INTO PickupPoint(AddressText) VALUES (N'410542, г. Лесной, ул. Светлая, 46');
INSERT INTO PickupPoint(AddressText) VALUES (N'620839, г. Лесной, ул. Цветочная, 8');
INSERT INTO PickupPoint(AddressText) VALUES (N'443890, г. Лесной, ул. Коммунистическая, 1');
INSERT INTO PickupPoint(AddressText) VALUES (N'603379, г. Лесной, ул. Спортивная, 46');
INSERT INTO PickupPoint(AddressText) VALUES (N'603721, г. Лесной, ул. Гоголя, 41');
INSERT INTO PickupPoint(AddressText) VALUES (N'410172, г. Лесной, ул. Северная, 13');
INSERT INTO PickupPoint(AddressText) VALUES (N'614611, г. Лесной, ул. Молодежная, 50');
INSERT INTO PickupPoint(AddressText) VALUES (N'454311, г.Лесной, ул. Новая, 19');
INSERT INTO PickupPoint(AddressText) VALUES (N'660007, г.Лесной, ул. Октябрьская, 19');
INSERT INTO PickupPoint(AddressText) VALUES (N'603036, г. Лесной, ул. Садовая, 4');
INSERT INTO PickupPoint(AddressText) VALUES (N'394060, г.Лесной, ул. Фрунзе, 43');
INSERT INTO PickupPoint(AddressText) VALUES (N'410661, г. Лесной, ул. Школьная, 50');
INSERT INTO PickupPoint(AddressText) VALUES (N'625590, г. Лесной, ул. Коммунистическая, 20');
INSERT INTO PickupPoint(AddressText) VALUES (N'625683, г. Лесной, ул. 8 Марта');
INSERT INTO PickupPoint(AddressText) VALUES (N'450983, г.Лесной, ул. Комсомольская, 26');
INSERT INTO PickupPoint(AddressText) VALUES (N'394782, г. Лесной, ул. Чехова, 3');
INSERT INTO PickupPoint(AddressText) VALUES (N'603002, г. Лесной, ул. Дзержинского, 28');
INSERT INTO PickupPoint(AddressText) VALUES (N'450558, г. Лесной, ул. Набережная, 30');
INSERT INTO PickupPoint(AddressText) VALUES (N'344288, г. Лесной, ул. Чехова, 1');
INSERT INTO PickupPoint(AddressText) VALUES (N'614164, г.Лесной,  ул. Степная, 30');
INSERT INTO PickupPoint(AddressText) VALUES (N'394242, г. Лесной, ул. Коммунистическая, 43');
INSERT INTO PickupPoint(AddressText) VALUES (N'660540, г. Лесной, ул. Солнечная, 25');
INSERT INTO PickupPoint(AddressText) VALUES (N'125837, г. Лесной, ул. Шоссейная, 40');
INSERT INTO PickupPoint(AddressText) VALUES (N'125703, г. Лесной, ул. Партизанская, 49');
INSERT INTO PickupPoint(AddressText) VALUES (N'625283, г. Лесной, ул. Победы, 46');
INSERT INTO PickupPoint(AddressText) VALUES (N'614753, г. Лесной, ул. Полевая, 35');
INSERT INTO PickupPoint(AddressText) VALUES (N'426030, г. Лесной, ул. Маяковского, 44');
INSERT INTO PickupPoint(AddressText) VALUES (N'450375, г. Лесной ул. Клубная, 44');
INSERT INTO PickupPoint(AddressText) VALUES (N'625560, г. Лесной, ул. Некрасова, 12');
INSERT INTO PickupPoint(AddressText) VALUES (N'630201, г. Лесной, ул. Комсомольская, 17');
INSERT INTO PickupPoint(AddressText) VALUES (N'190949, г. Лесной, ул. Мичурина, 26');
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Никифорова Весения Николаевна', N'94d5ous@gmail.com', N'uzWC67'
FROM Role WHERE RoleName = N'Администратор';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Сазонов Руслан Германович', N'uth4iz@mail.com', N'2L6KZG'
FROM Role WHERE RoleName = N'Администратор';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Одинцов Серафим Артёмович', N'5d4zbu@tutanota.com', N'rwVDh9'
FROM Role WHERE RoleName = N'Администратор';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Ситдикова Елена Анатольевна', N'ptec8ym@yahoo.com', N'LdNyos'
FROM Role WHERE RoleName = N'Менеджер';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Ворсин Петр Евгеньевич', N'1qz4kw@mail.com', N'gynQMT'
FROM Role WHERE RoleName = N'Менеджер';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Старикова Елена Павловна', N'4np6se@mail.com', N'AtnDjr'
FROM Role WHERE RoleName = N'Менеджер';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Никифорова Анна Семеновна', N'yzls62@outlook.com', N'JlFRCZ'
FROM Role WHERE RoleName = N'Авторизированный клиент';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Стелина Евгения Петровна', N'1diph5e@tutanota.com', N'8ntwUp'
FROM Role WHERE RoleName = N'Авторизированный клиент';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Михайлюк Анна Вячеславовна', N'tjde7c@yahoo.com', N'YOyhfR'
FROM Role WHERE RoleName = N'Авторизированный клиент';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText)
SELECT RoleId, N'Степанов Михаил Артёмович', N'wpmrc3do@tutanota.com', N'RSbvHv'
FROM Role WHERE RoleName = N'Авторизированный клиент';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'А112Т4', N'Велосипед взрослый горный Slash Stream 27.5 колеса (2025) 17" Черный (162-172 см)', u.UnitId, 19775.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 30.00, 15, N'Горный велосипед Slash Stream 27.5 (2025) – легкий и надежный компаньон для поездок по пересеченной местности. Мощные шатуны интенсивно передают усилия мышц на вал каретки. ', N'Resources\\1.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'ВелоСтрана'
  AND m.ManufacturerName = N'Slash'
  AND c.CategoryName = N'Велосипед взрослый горный';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'G843H5', N'Велосипед взрослый горный Slash Stream 27.5 колеса (2025) 19" Синий (172-182 см)', u.UnitId, 19791.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 30.00, 9, N'В комплектацию включены дисковые механические тормоза RPT DSC-310. Особый упор разработчики рамы данной модели сделали на увеличение прочности мест наибольшей нагрузки. ', N'Resources\\2.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'ВелоСтрана'
  AND m.ManufacturerName = N'Slash'
  AND c.CategoryName = N'Велосипед взрослый горный';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'D325D4', N'Велосипед городской подростковый серый', u.UnitId, 9919.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 5.00, 12, N'Городской подростковый велосипед - идеальный выбор для активного образа жизни!
Откройте для себя комфорт и свободу передвижения с нашим стильным городским велосипедом. ', N'Resources\\3.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'ЯндексМаркет'
  AND m.ManufacturerName = N'Shimano'
  AND c.CategoryName = N'Велосипед городской подростковый';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'S432T5', N'Велосипед Skill Bike 3051, городской, 21 скорость, сталь, 29" колеса, черно-красный', u.UnitId, 16442.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 15.00, 15, N'SKILL BIKE модель 3051 - горный велосипед на спицах, обеспечивающий уверенную и комфортную езду как по городским улицам, так и по горной местности.', N'Resources\\4.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'Скилс'
  AND m.ManufacturerName = N'Skill bike'
  AND c.CategoryName = N'Велосипед городской взрослый';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'F325D4', N'Велосипед Skillbike 3052, горный, складной, рама 17 дюймов, колеса 26 дюймов, 21 скорость', u.UnitId, 17985.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 18.00, 50, N'SKILL BIKE модель 3052 - велосипед складной, предназначен для тех, кто ценит комфорт, стиль и максимальную мобильность. Горный велосипед легко помещается в багажник и идеально подходит для активных поездок в городской суете.', N'Resources\\5.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'Скилс'
  AND m.ManufacturerName = N'Skill bike'
  AND c.CategoryName = N'Велосипед взрослый горный';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'G432G6', N'Велосипед Skill Bike 3053, горный, двухподвесный, рама 17 дюймов, колеса 26 дюймов, 21 скорость', u.UnitId, 17621.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 20.00, 0, N'SKILL BIKE модель 3053 - горный велосипед на литых дисках, имеет амортизаторы как на переднем, так и на заднем колесе.', N'Resources\\6.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'Скилс'
  AND m.ManufacturerName = N'Skill bike'
  AND c.CategoryName = N'Велосипед взрослый горный';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'H542F5', N'Велосипед MILANO M300, горный, для взрослых, 26", 7 скоростей', u.UnitId, 13509.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 4.00, 5, N'Горный велосипед MILANO M300 с диаметром колес 26 дюйма подойдет для подростков и взрослых, без усилий позволит преодолевать любые непроходимые каменистые поверхности и зоны бездорожья.', N'Resources\\7.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'ПерспективаГрупп'
  AND m.ManufacturerName = N'NEXT'
  AND c.CategoryName = N'Велосипед взрослый горный';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'C346F5', N'Горный велосипед скоростной, колёса 24", рама - 14", черно-красный', u.UnitId, 15212.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 5.00, 4, N'Горный велосипед – это надежный и стильный выбор для любителей активного отдыха. Удобное седло из искусственной кожи и наличие подножки добавляют удобства во время поездок.', N'Resources\\8.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'ПерспективаГрупп'
  AND m.ManufacturerName = N'
Aero'
  AND c.CategoryName = N'Велосипед детский горный';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'F256G6', N'26" Велосипед Fizard, 15" алюминий, дисковые тормоза, 21 скорость, серый', u.UnitId, 15126.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 25.00, 3, N'Горный велосипед Fizard — надёжный универсальный маунтинбайк для города и бездорожья.', N'Resources\\9.jpg'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'ПерспективаГрупп'
  AND m.ManufacturerName = N'Fizard'
  AND c.CategoryName = N'Велосипед детский горный';
INSERT INTO Item(Article, ItemName, UnitId, Price, SupplierId, ManufacturerId, CategoryId, DiscountPercent, StockQuantity, Description, ImagePath)
SELECT N'J532V5', N'Велосипед двухколесный детский 14 дюймов, со светящимися колесами, черный', u.UnitId, 6417.00, s.SupplierId, m.ManufacturerId, c.CategoryId, 8.00, 6, N'
Велосипед двухколесный детский 14 дюймов от Kari - это надежный и безопасный транспорт для вашего ребенка.', N'Resources\\nan'
FROM Unit u CROSS JOIN Supplier s CROSS JOIN Manufacturer m CROSS JOIN Category c
WHERE u.UnitName = N'шт.'
  AND s.SupplierName = N'kari'
  AND m.ManufacturerName = N'kari'
  AND c.CategoryName = N'Велосипед детский городской';
SET IDENTITY_INSERT OrderHeader ON;
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 1, '2023-02-27', '2023-04-20', pp.PickupPointId, N'Степанов Михаил Артёмович', 901, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 1
  AND os.StatusName = N'Новый';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 2, '2022-09-28', '2023-04-21', pp.PickupPointId, N'Никифорова Весения Николаевна', 902, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 11
  AND os.StatusName = N'Новый';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 3, '2023-03-21', '2023-04-22', pp.PickupPointId, N'Сазонов Руслан Германович', 903, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 2
  AND os.StatusName = N'Новый';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 4, '2023-02-20', '2023-04-23', pp.PickupPointId, N'Одинцов Серафим Артёмович', 904, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 11
  AND os.StatusName = N'Завершен';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 5, '2023-03-17', '2023-04-24', pp.PickupPointId, N'Степанов Михаил Артёмович', 905, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 2
  AND os.StatusName = N'Завершен';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 6, '2023-03-01', '2023-04-25', pp.PickupPointId, N'Никифорова Весения Николаевна', 906, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 15
  AND os.StatusName = N'Завершен';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 7, '2023-02-28', '2023-04-26', pp.PickupPointId, N'Сазонов Руслан Германович', 907, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 3
  AND os.StatusName = N'Завершен';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 8, '2023-03-31', '2023-04-27', pp.PickupPointId, N'Одинцов Серафим Артёмович', 908, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 19
  AND os.StatusName = N'Новый';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 9, '2023-04-02', '2023-04-28', pp.PickupPointId, N'Степанов Михаил Артёмович', 909, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 5
  AND os.StatusName = N'Новый';
INSERT INTO OrderHeader(OrderId, OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
SELECT 10, '2023-04-03', '2023-04-29', pp.PickupPointId, N'Степанов Михаил Артёмович', 910, os.OrderStatusId
FROM PickupPoint pp CROSS JOIN OrderStatus os
WHERE pp.PickupPointId = 19
  AND os.StatusName = N'Новый';
SET IDENTITY_INSERT OrderHeader OFF;
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 1, ItemId, 2
FROM Item WHERE Article = N'А112Т4';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 1, ItemId, 2
FROM Item WHERE Article = N'G843H5';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 2, ItemId, 1
FROM Item WHERE Article = N'G843H5';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 2, ItemId, 1
FROM Item WHERE Article = N'А112Т4';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 3, ItemId, 10
FROM Item WHERE Article = N'D325D4';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 3, ItemId, 10
FROM Item WHERE Article = N'S432T5';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 4, ItemId, 5
FROM Item WHERE Article = N'F325D4';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 4, ItemId, 4
FROM Item WHERE Article = N'D325D4';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 5, ItemId, 20
FROM Item WHERE Article = N'G432G6';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 5, ItemId, 20
FROM Item WHERE Article = N'H542F5';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 6, ItemId, 2
FROM Item WHERE Article = N'А112Т4';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 6, ItemId, 2
FROM Item WHERE Article = N'G843H5';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 7, ItemId, 3
FROM Item WHERE Article = N'C346F5';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 7, ItemId, 3
FROM Item WHERE Article = N'F256G6';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 8, ItemId, 1
FROM Item WHERE Article = N'F325D4';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 8, ItemId, 1
FROM Item WHERE Article = N'G432G6';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 9, ItemId, 5
FROM Item WHERE Article = N'J532V5';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 9, ItemId, 1
FROM Item WHERE Article = N'F256G6';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 10, ItemId, 5
FROM Item WHERE Article = N'F256G6';
INSERT INTO OrderItem(OrderId, ItemId, Quantity)
SELECT 10, ItemId, 5
FROM Item WHERE Article = N'J532V5';
GO

CREATE VIEW ViewItemList AS
SELECT
    i.ItemId, i.Article, i.ItemName, c.CategoryName, i.Description,
    m.ManufacturerName, s.SupplierName, i.Price, u.UnitName,
    i.StockQuantity, i.DiscountPercent,
    CAST(i.Price * (100 - i.DiscountPercent) / 100 AS DECIMAL(12,2)) AS FinalPrice,
    i.ImagePath
FROM Item i
JOIN Category c ON c.CategoryId = i.CategoryId
JOIN Manufacturer m ON m.ManufacturerId = i.ManufacturerId
JOIN Supplier s ON s.SupplierId = i.SupplierId
JOIN Unit u ON u.UnitId = i.UnitId;
GO

CREATE VIEW ViewOrderList AS
SELECT
    oh.OrderId, oh.OrderDate, oh.DeliveryDate, pp.AddressText,
    oh.CustomerName, oh.ReceiveCode, os.StatusName,
    STUFF((
        SELECT N', ' + i2.Article + N' x ' + CAST(oi2.Quantity AS NVARCHAR(10))
        FROM OrderItem oi2
        JOIN Item i2 ON i2.ItemId = oi2.ItemId
        WHERE oi2.OrderId = oh.OrderId
        FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, N'') AS ItemsText
FROM OrderHeader oh
JOIN PickupPoint pp ON pp.PickupPointId = oh.PickupPointId
JOIN OrderStatus os ON os.OrderStatusId = oh.OrderStatusId;
GO
