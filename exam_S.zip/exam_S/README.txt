Порядок запуска:
1. В SQL Server Management Studio 18 открыть Database/CreateDatabase.sql и выполнить весь скрипт.
2. Открыть BicycleDrive.sln в Visual Studio.
3. В BicycleDrive/App.config поменять Data Source при необходимости: .\SQLEXPRESS, localhost или имя своего сервера.
4. Запустить проект.
5. Логины и пароли находятся в таблице AppUser. Можно войти как гость.
