using System.Windows.Forms;
using System.Drawing;

namespace BicycleDrive
{
    partial class ItemEditForm
    {
        private Label lblTitle;
        private Label lblArticle;
        private Label lblName;
        private Label lblCategory;
        private Label lblManufacturer;
        private Label lblSupplier;
        private Label lblUnit;
        private Label lblPrice;
        private Label lblStock;
        private Label lblDiscount;
        private Label lblDescription;
        private TextBox txtArticle, txtName, txtDescription, txtPrice, txtStock, txtDiscount, txtImage;
        private ComboBox cmbCategory, cmbManufacturer, cmbSupplier, cmbUnit;
        private Button btnChooseImage, btnSave, btnCancel, btnDelete;
        private PictureBox picItem;

        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblArticle = new Label();
            lblName = new Label();
            lblCategory = new Label();
            lblManufacturer = new Label();
            lblSupplier = new Label();
            lblUnit = new Label();
            lblPrice = new Label();
            lblStock = new Label();
            lblDiscount = new Label();
            lblDescription = new Label();
            txtArticle = new TextBox();
            txtName = new TextBox();
            txtDescription = new TextBox();
            txtPrice = new TextBox();
            txtStock = new TextBox();
            txtDiscount = new TextBox();
            txtImage = new TextBox();
            cmbCategory = new ComboBox();
            cmbManufacturer = new ComboBox();
            cmbSupplier = new ComboBox();
            cmbUnit = new ComboBox();
            btnChooseImage = new Button();
            btnSave = new Button();
            btnCancel = new Button();
            btnDelete = new Button();
            picItem = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)(picItem)).BeginInit();
            SuspendLayout();

            lblTitle.Text = "Товар";
            lblTitle.Font = new Font("Arial", 16F, FontStyle.Bold);
            lblTitle.Location = new Point(20, 15);
            lblTitle.Size = new Size(600, 35);

            lblArticle.Text = "Артикул";
            lblArticle.Location = new Point(20, 60);
            lblArticle.Size = new Size(180, 22);
            txtArticle.Location = new Point(20, 85);
            txtArticle.Size = new Size(180, 25);

            lblName.Text = "Наименование";
            lblName.Location = new Point(220, 60);
            lblName.Size = new Size(180, 22);
            txtName.Location = new Point(220, 85);
            txtName.Size = new Size(410, 25);

            lblCategory.Text = "Категория";
            lblCategory.Location = new Point(20, 120);
            lblCategory.Size = new Size(180, 22);
            cmbCategory.Location = new Point(20, 145);
            cmbCategory.Size = new Size(290, 25);
            cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList;

            lblManufacturer.Text = "Производитель";
            lblManufacturer.Location = new Point(340, 120);
            lblManufacturer.Size = new Size(180, 22);
            cmbManufacturer.Location = new Point(340, 145);
            cmbManufacturer.Size = new Size(290, 25);
            cmbManufacturer.DropDownStyle = ComboBoxStyle.DropDownList;

            lblSupplier.Text = "Поставщик";
            lblSupplier.Location = new Point(20, 180);
            lblSupplier.Size = new Size(180, 22);
            cmbSupplier.Location = new Point(20, 205);
            cmbSupplier.Size = new Size(290, 25);
            cmbSupplier.DropDownStyle = ComboBoxStyle.DropDownList;

            lblUnit.Text = "Ед. изм.";
            lblUnit.Location = new Point(340, 180);
            lblUnit.Size = new Size(180, 22);
            cmbUnit.Location = new Point(340, 205);
            cmbUnit.Size = new Size(120, 25);
            cmbUnit.DropDownStyle = ComboBoxStyle.DropDownList;

            lblPrice.Text = "Цена";
            lblPrice.Location = new Point(20, 240);
            lblPrice.Size = new Size(120, 22);
            txtPrice.Location = new Point(20, 265);
            txtPrice.Size = new Size(120, 25);

            lblStock.Text = "Количество";
            lblStock.Location = new Point(160, 240);
            lblStock.Size = new Size(120, 22);
            txtStock.Location = new Point(160, 265);
            txtStock.Size = new Size(120, 25);

            lblDiscount.Text = "Скидка %";
            lblDiscount.Location = new Point(300, 240);
            lblDiscount.Size = new Size(120, 22);
            txtDiscount.Location = new Point(300, 265);
            txtDiscount.Size = new Size(120, 25);

            lblDescription.Text = "Описание";
            lblDescription.Location = new Point(20, 300);
            lblDescription.Size = new Size(180, 22);
            txtDescription.Location = new Point(20, 325);
            txtDescription.Size = new Size(610, 90);
            txtDescription.Multiline = true;

            picItem.Location = new Point(660, 85);
            picItem.Size = new Size(300, 200);
            picItem.SizeMode = PictureBoxSizeMode.Zoom;

            txtImage.Location = new Point(660, 300);
            txtImage.Size = new Size(220, 25);
            txtImage.ReadOnly = true;

            btnChooseImage.Text = "...";
            btnChooseImage.Location = new Point(890, 300);
            btnChooseImage.Size = new Size(70, 25);
            btnChooseImage.Click += btnChooseImage_Click;

            btnDelete.Text = "Удалить";
            btnDelete.Location = new Point(625, 380);
            btnDelete.Size = new Size(105, 35);
            btnDelete.Click += btnDelete_Click;

            btnSave.Text = "Сохранить";
            btnSave.Location = new Point(740, 380);
            btnSave.Size = new Size(105, 35);
            btnSave.Click += btnSave_Click;

            btnCancel.Text = "Отмена";
            btnCancel.Location = new Point(855, 380);
            btnCancel.Size = new Size(105, 35);
            btnCancel.Click += btnCancel_Click;

            ClientSize = new Size(990, 445);
            Controls.Add(lblTitle);
            Controls.Add(lblArticle);
            Controls.Add(lblName);
            Controls.Add(lblCategory);
            Controls.Add(lblManufacturer);
            Controls.Add(lblSupplier);
            Controls.Add(lblUnit);
            Controls.Add(lblPrice);
            Controls.Add(lblStock);
            Controls.Add(lblDiscount);
            Controls.Add(lblDescription);
            Controls.Add(txtArticle);
            Controls.Add(txtName);
            Controls.Add(txtDescription);
            Controls.Add(txtPrice);
            Controls.Add(txtStock);
            Controls.Add(txtDiscount);
            Controls.Add(txtImage);
            Controls.Add(cmbCategory);
            Controls.Add(cmbManufacturer);
            Controls.Add(cmbSupplier);
            Controls.Add(cmbUnit);
            Controls.Add(btnChooseImage);
            Controls.Add(btnDelete);
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            Controls.Add(picItem);
            StartPosition = FormStartPosition.CenterParent;
            Text = "Товар";
            ((System.ComponentModel.ISupportInitialize)(picItem)).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
