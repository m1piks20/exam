using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace BicycleDrive
{
    internal static class ImageHelper
    {
        public static string GetAbsoluteImagePath(string relativePath)
        {
            string stub = Path.Combine(Application.StartupPath, "Resources", "picture.png");
            if (string.IsNullOrWhiteSpace(relativePath)) return stub;

            string path = Path.Combine(Application.StartupPath, relativePath);
            return File.Exists(path) ? path : stub;
        }

        public static string CopyItemImage(string sourcePath, string oldRelativePath)
        {
            if (string.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath)) return oldRelativePath;

            string dir = Path.Combine(Application.StartupPath, "Resources", "Items");
            Directory.CreateDirectory(dir);

            string fileName = "item_" + System.DateTime.Now.ToString("yyyyMMddHHmmssfff") + ".jpg";
            string target = Path.Combine(dir, fileName);

            using (Image source = Image.FromFile(sourcePath))
            using (Bitmap result = Resize(source, 300, 200))
            {
                result.Save(target, ImageFormat.Jpeg);
            }

            if (!string.IsNullOrWhiteSpace(oldRelativePath))
            {
                string oldPath = Path.Combine(Application.StartupPath, oldRelativePath);
                if (File.Exists(oldPath) && !oldPath.Contains(Path.Combine("Resources", "picture.png")))
                {
                    try { File.Delete(oldPath); } catch { }
                }
            }

            return Path.Combine("Resources", "Items", fileName);
        }

        private static Bitmap Resize(Image image, int maxWidth, int maxHeight)
        {
            double ratio = System.Math.Min((double)maxWidth / image.Width, (double)maxHeight / image.Height);
            int width = (int)(image.Width * ratio);
            int height = (int)(image.Height * ratio);

            Bitmap result = new Bitmap(maxWidth, maxHeight);
            using (Graphics graphics = Graphics.FromImage(result))
            {
                graphics.Clear(Color.White);
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                int x = (maxWidth - width) / 2;
                int y = (maxHeight - height) / 2;
                graphics.DrawImage(image, x, y, width, height);
            }

            return result;
        }
    }
}
