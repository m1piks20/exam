using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BicycleDrive
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            Style.Apply(this);
            Style.AccentButton(btnLogin);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLogin.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Введите логин и пароль.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable user = Db.Query(
                @"SELECT TOP 1 u.UserId, u.FullName, r.RoleName
                  FROM AppUser u
                  JOIN Role r ON r.RoleId = u.RoleId
                  WHERE u.Login = @login AND u.PasswordText = @password",
                new SqlParameter("@login", txtLogin.Text.Trim()),
                new SqlParameter("@password", txtPassword.Text.Trim()));

            if (user.Rows.Count == 0)
            {
                MessageBox.Show("Пользователь не найден. Проверьте логин и пароль.", "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Session.UserId = Convert.ToInt32(user.Rows[0]["UserId"]);
            Session.FullName = Convert.ToString(user.Rows[0]["FullName"]);
            Session.RoleName = Convert.ToString(user.Rows[0]["RoleName"]);

            OpenMainForm();
        }

        private void btnGuest_Click(object sender, EventArgs e)
        {
            Session.SetGuest();
            OpenMainForm();
        }

        private void OpenMainForm()
        {
            Hide();
            using (MainForm form = new MainForm())
            {
                form.ShowDialog();
            }
            Session.Clear();
            txtPassword.Clear();
            Show();
        }
    }
}
