using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace BicycleDrive
{
    public partial class ItemEditForm : Form
    {
        private readonly int? itemId;
        private string selectedImagePath;
        private string oldImagePath;

        public ItemEditForm(int? itemId)
        {
            this.itemId = itemId;
            InitializeComponent();
            Style.Apply(this);
            Style.AccentButton(btnSave);
            Style.AccentButton(btnDelete);
            btnDelete.Visible = itemId.HasValue && Session.IsAdmin;
            Text = itemId.HasValue ? "Редактирование товара" : "Добавление товара";
            lblTitle.Text = Text;

            LoadDictionaries();
            if (itemId.HasValue) LoadItem();
            else ShowImage(null);
        }

        private void LoadDictionaries()
        {
            FillCombo(cmbCategory, "SELECT CategoryId, CategoryName FROM Category ORDER BY CategoryName", "CategoryName", "CategoryId");
            FillCombo(cmbManufacturer, "SELECT ManufacturerId, ManufacturerName FROM Manufacturer ORDER BY ManufacturerName", "ManufacturerName", "ManufacturerId");
            FillCombo(cmbSupplier, "SELECT SupplierId, SupplierName FROM Supplier ORDER BY SupplierName", "SupplierName", "SupplierId");
            FillCombo(cmbUnit, "SELECT UnitId, UnitName FROM Unit ORDER BY UnitName", "UnitName", "UnitId");
        }

        private void FillCombo(ComboBox combo, string sql, string display, string value)
        {
            combo.DataSource = Db.Query(sql);
            combo.DisplayMember = display;
            combo.ValueMember = value;
        }

        private void LoadItem()
        {
            DataTable table = Db.Query("SELECT * FROM Item WHERE ItemId = @id", new SqlParameter("@id", itemId.Value));
            if (table.Rows.Count == 0) return;

            DataRow row = table.Rows[0];
            txtArticle.Text = Convert.ToString(row["Article"]);
            txtName.Text = Convert.ToString(row["ItemName"]);
            txtDescription.Text = Convert.ToString(row["Description"]);
            txtPrice.Text = Convert.ToDecimal(row["Price"]).ToString("0.00");
            txtStock.Text = Convert.ToString(row["StockQuantity"]);
            txtDiscount.Text = Convert.ToDecimal(row["DiscountPercent"]).ToString("0.00");
            cmbCategory.SelectedValue = row["CategoryId"];
            cmbManufacturer.SelectedValue = row["ManufacturerId"];
            cmbSupplier.SelectedValue = row["SupplierId"];
            cmbUnit.SelectedValue = row["UnitId"];
            oldImagePath = Convert.ToString(row["ImagePath"]);
            ShowImage(oldImagePath);
        }

        private void ShowImage(string relativePath)
        {
            txtImage.Text = relativePath;
            picItem.Image = Image.FromFile(ImageHelper.GetAbsoluteImagePath(relativePath));
        }

        private void btnChooseImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                selectedImagePath = dialog.FileName;
                picItem.Image = Image.FromFile(selectedImagePath);
                txtImage.Text = selectedImagePath;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            decimal price, discount;
            int stock;

            if (string.IsNullOrWhiteSpace(txtArticle.Text) || string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Заполните артикул и наименование.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtPrice.Text, out price) || price < 0)
            {
                MessageBox.Show("Цена должна быть неотрицательным числом.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtStock.Text, out stock) || stock < 0)
            {
                MessageBox.Show("Количество на складе должно быть неотрицательным целым числом.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtDiscount.Text, out discount) || discount < 0 || discount > 100)
            {
                MessageBox.Show("Скидка должна быть числом от 0 до 100.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string imagePath = ImageHelper.CopyItemImage(selectedImagePath, oldImagePath);

            if (itemId.HasValue)
            {
                Db.Execute(@"UPDATE Item SET Article=@article, ItemName=@name, CategoryId=@category, Description=@description,
                            ManufacturerId=@manufacturer, SupplierId=@supplier, UnitId=@unit, Price=@price,
                            StockQuantity=@stock, DiscountPercent=@discount, ImagePath=@image WHERE ItemId=@id",
                    Parameters(price, stock, discount, imagePath, new SqlParameter("@id", itemId.Value)));
            }
            else
            {
                Db.Execute(@"INSERT INTO Item(Article, ItemName, CategoryId, Description, ManufacturerId, SupplierId, UnitId, Price, StockQuantity, DiscountPercent, ImagePath)
                             VALUES(@article, @name, @category, @description, @manufacturer, @supplier, @unit, @price, @stock, @discount, @image)",
                    Parameters(price, stock, discount, imagePath));
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private SqlParameter[] Parameters(decimal price, int stock, decimal discount, string imagePath, params SqlParameter[] extra)
        {
            var list = new System.Collections.Generic.List<SqlParameter>
            {
                new SqlParameter("@article", txtArticle.Text.Trim()),
                new SqlParameter("@name", txtName.Text.Trim()),
                new SqlParameter("@category", cmbCategory.SelectedValue),
                new SqlParameter("@description", txtDescription.Text.Trim()),
                new SqlParameter("@manufacturer", cmbManufacturer.SelectedValue),
                new SqlParameter("@supplier", cmbSupplier.SelectedValue),
                new SqlParameter("@unit", cmbUnit.SelectedValue),
                new SqlParameter("@price", price),
                new SqlParameter("@stock", stock),
                new SqlParameter("@discount", discount),
                new SqlParameter("@image", (object)imagePath ?? DBNull.Value)
            };
            list.AddRange(extra);
            return list.ToArray();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!itemId.HasValue) return;

            int orderCount = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM OrderItem WHERE ItemId = @id", new SqlParameter("@id", itemId.Value)));
            if (orderCount > 0)
            {
                MessageBox.Show("Товар присутствует в заказе, поэтому удалить его нельзя.", "Удаление запрещено", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Удалить этот товар? Операцию нельзя отменить.", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            Db.Execute("DELETE FROM Item WHERE ItemId = @id", new SqlParameter("@id", itemId.Value));
            DeleteOldImageFile();
            DialogResult = DialogResult.OK;
            Close();
        }

        private void DeleteOldImageFile()
        {
            if (string.IsNullOrWhiteSpace(oldImagePath)) return;
            string path = Path.Combine(Application.StartupPath, oldImagePath);
            if (!File.Exists(path)) return;
            if (oldImagePath.Equals(Path.Combine("Resources", "picture.png"), StringComparison.OrdinalIgnoreCase)) return;
            try { File.Delete(path); } catch { }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
