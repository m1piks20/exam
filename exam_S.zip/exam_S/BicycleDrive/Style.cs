using System.Drawing;
using System.Windows.Forms;

namespace BicycleDrive
{
    internal static class Style
    {
        public static readonly Color MainBackColor = ColorTranslator.FromHtml("#FFFFFF");
        public static readonly Color SecondBackColor = ColorTranslator.FromHtml("#6A5ACD");
        public static readonly Color AccentColor = ColorTranslator.FromHtml("#4B0082");
        public static readonly Color DiscountBackColor = ColorTranslator.FromHtml("#483D8B");

        public static void Apply(Form form)
        {
            form.BackColor = MainBackColor;
            form.Font = new Font("Arial", 10F, FontStyle.Regular);
            string iconPath = System.IO.Path.Combine(Application.StartupPath, "Resources", "icon.ico");
            if (System.IO.File.Exists(iconPath))
            {
                form.Icon = new Icon(iconPath);
            }
        }

        public static void AccentButton(Button button)
        {
            button.BackColor = AccentColor;
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
        }
    }
}
