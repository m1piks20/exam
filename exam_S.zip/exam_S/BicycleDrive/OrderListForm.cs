using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace BicycleDrive
{
    public partial class OrderListForm : Form
    {
        private DataTable orderTable;
        private int selectedOrderId;

        public OrderListForm()
        {
            InitializeComponent();
            Style.Apply(this);
            Style.AccentButton(btnAddOrder);
            Style.AccentButton(btnClose);
            btnAddOrder.Visible = Session.IsAdmin;
            btnDeleteOrder.Visible = false;
            LoadOrders();
        }

        private void LoadOrders()
        {
            selectedOrderId = 0;
            orderTable = Db.Query("SELECT * FROM ViewOrderList ORDER BY OrderId");
            RenderOrders();
        }

        private void RenderOrders()
        {
            flpOrders.SuspendLayout();
            flpOrders.Controls.Clear();

            foreach (DataRow row in orderTable.Rows)
            {
                flpOrders.Controls.Add(CreateOrderCard(row));
            }

            flpOrders.ResumeLayout();
        }

        private Panel CreateOrderCard(DataRow row)
        {
            int orderId = Convert.ToInt32(row["OrderId"]);
            Panel card = new Panel();
            card.Tag = orderId;
            card.Width = 815;
            card.Height = 118;
            card.Margin = new Padding(4, 4, 4, 10);
            card.BackColor = Color.White;
            card.Cursor = Cursors.Hand;
            card.Paint += OrderCard_Paint;
            card.Click += OrderCard_Click;
            card.DoubleClick += OrderCard_DoubleClick;

            Panel infoPanel = new Panel();
            infoPanel.Location = new Point(18, 14);
            infoPanel.Size = new Size(590, 90);
            infoPanel.BorderStyle = BorderStyle.FixedSingle;

            infoPanel.Controls.Add(CreateLabel("Артикул заказа: " + Convert.ToString(row["ItemsText"]), 10, 8, 560, 18, true));
            infoPanel.Controls.Add(CreateLabel("Статус заказа: " + Convert.ToString(row["StatusName"]), 10, 28, 560, 18, false));
            infoPanel.Controls.Add(CreateLabel("Адрес пункта выдачи: " + Convert.ToString(row["AddressText"]), 10, 48, 560, 18, false));
            infoPanel.Controls.Add(CreateLabel("Дата заказа: " + FormatDate(row["OrderDate"]), 10, 68, 560, 18, false));

            Panel datePanel = new Panel();
            datePanel.Location = new Point(630, 14);
            datePanel.Size = new Size(160, 90);
            datePanel.BorderStyle = BorderStyle.FixedSingle;
            Label deliveryTitle = CreateLabel("Дата доставки", 10, 20, 140, 20, true);
            deliveryTitle.TextAlign = ContentAlignment.MiddleCenter;
            Label deliveryDate = CreateLabel(FormatDate(row["DeliveryDate"]), 10, 48, 140, 20, false);
            deliveryDate.TextAlign = ContentAlignment.MiddleCenter;
            datePanel.Controls.Add(deliveryTitle);
            datePanel.Controls.Add(deliveryDate);

            card.Controls.Add(infoPanel);
            card.Controls.Add(datePanel);

            BindOrderCardEvents(card, card);
            return card;
        }

        private void BindOrderCardEvents(Control parent, Panel card)
        {
            foreach (Control control in parent.Controls)
            {
                control.Cursor = Cursors.Hand;
                control.Click += (s, e) => OpenSelectedCard(card);
                control.DoubleClick += (s, e) => OpenSelectedCard(card);

                if (control.HasChildren)
                {
                    BindOrderCardEvents(control, card);
                }
            }
        }

        private Label CreateLabel(string text, int x, int y, int width, int height, bool bold)
        {
            Label label = new Label();
            label.Text = text;
            label.Location = new Point(x, y);
            label.Size = new Size(width, height);
            label.Font = new Font("Arial", 9.5F, bold ? FontStyle.Bold : FontStyle.Regular);
            label.AutoEllipsis = true;
            return label;
        }

        private string FormatDate(object value)
        {
            if (value == DBNull.Value || value == null) return "";
            return Convert.ToDateTime(value).ToString("dd.MM.yyyy");
        }

        private void OrderCard_Paint(object sender, PaintEventArgs e)
        {
            Panel card = (Panel)sender;
            bool isSelected = Convert.ToInt32(card.Tag) == selectedOrderId;
            using (Pen pen = new Pen(isSelected ? Style.AccentColor : Color.Black, isSelected ? 4 : 2))
            {
                e.Graphics.SmoothingMode = SmoothingMode.None;
                e.Graphics.DrawRectangle(pen, 1, 1, card.Width - 3, card.Height - 3);
            }
        }

        private void OrderCard_Click(object sender, EventArgs e)
        {
            OpenSelectedCard((Panel)sender);
        }

        private void OrderCard_DoubleClick(object sender, EventArgs e)
        {
            OpenSelectedCard((Panel)sender);
        }

        private void SelectOrderCard(Panel card)
        {
            selectedOrderId = Convert.ToInt32(card.Tag);
            foreach (Control control in flpOrders.Controls) control.Invalidate();
        }

        private void OpenSelectedCard(Panel card)
        {
            SelectOrderCard(card);
            if (!Session.IsAdmin) return;
            using (OrderEditForm form = new OrderEditForm(selectedOrderId))
            {
                if (form.ShowDialog() == DialogResult.OK) LoadOrders();
            }
        }

        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            using (OrderEditForm form = new OrderEditForm(null))
            {
                if (form.ShowDialog() == DialogResult.OK) LoadOrders();
            }
        }

        private void btnDeleteOrder_Click(object sender, EventArgs e)
        {
            if (selectedOrderId == 0)
            {
                MessageBox.Show("Выберите заказ в списке.", "Удаление заказа", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Удалить выбранный заказ?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            Db.Execute("DELETE FROM OrderHeader WHERE OrderId = @id", new SqlParameter("@id", selectedOrderId));
            LoadOrders();
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
