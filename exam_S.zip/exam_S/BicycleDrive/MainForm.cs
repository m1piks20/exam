using System;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace BicycleDrive
{
    public partial class MainForm : Form
    {
        private DataTable itemTable;
        private bool itemEditOpened;
        private int selectedItemId;

        public MainForm()
        {
            InitializeComponent();
            Style.Apply(this);
            Style.AccentButton(btnAddItem);
            Style.AccentButton(btnOrders);
            Style.AccentButton(btnLogout);
            lblUser.Text = Session.FullName + " (" + Session.RoleName + ")";

            string logoPath = Path.Combine(Application.StartupPath, "Resources", "logo.png");
            if (File.Exists(logoPath)) picLogo.Image = Image.FromFile(logoPath);

            cmbDiscount.Items.AddRange(new object[] { "Все диапазоны", "0-11,99%", "12-18,99%", "19% и более" });
            cmbSort.Items.AddRange(new object[] { "Без сортировки", "Количество ↑", "Количество ↓", "Цена ↑", "Цена ↓", "Скидка ↑", "Скидка ↓" });
            cmbDiscount.SelectedIndex = 0;
            cmbSort.SelectedIndex = 0;

            bool allowAdvanced = Session.IsManager || Session.IsAdmin;
            txtSearch.Visible = lblSearch.Visible = allowAdvanced;
            cmbDiscount.Visible = lblDiscount.Visible = allowAdvanced;
            cmbSort.Visible = lblSort.Visible = allowAdvanced;
            btnOrders.Visible = allowAdvanced;
            btnAddItem.Visible = Session.IsAdmin;
            btnDeleteItem.Visible = false;

            LoadItems();
        }

        private void LoadItems()
        {
            selectedItemId = 0;
            itemTable = Db.Query("SELECT * FROM ViewItemList");
            ApplyFilter();
        }

        private void FilterChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void ApplyFilter()
        {
            if (itemTable == null) return;

            string filter = "";
            if ((Session.IsManager || Session.IsAdmin) && !string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                string value = txtSearch.Text.Replace("'", "''");
                filter = string.Format(
                    "(Article LIKE '%{0}%' OR ItemName LIKE '%{0}%' OR CategoryName LIKE '%{0}%' OR Description LIKE '%{0}%' OR ManufacturerName LIKE '%{0}%' OR SupplierName LIKE '%{0}%' OR UnitName LIKE '%{0}%')",
                    value);
            }

            if ((Session.IsManager || Session.IsAdmin) && cmbDiscount.SelectedIndex > 0)
            {
                string discountFilter = "";
                if (cmbDiscount.SelectedIndex == 1) discountFilter = "DiscountPercent >= 0 AND DiscountPercent < 12";
                if (cmbDiscount.SelectedIndex == 2) discountFilter = "DiscountPercent >= 12 AND DiscountPercent < 19";
                if (cmbDiscount.SelectedIndex == 3) discountFilter = "DiscountPercent >= 19";

                filter = string.IsNullOrEmpty(filter) ? discountFilter : filter + " AND " + discountFilter;
            }

            DataView view = new DataView(itemTable);
            view.RowFilter = filter;
            view.Sort = GetSort();
            RenderItems(view);
        }

        private string GetSort()
        {
            if (!(Session.IsManager || Session.IsAdmin)) return "ItemName ASC";
            switch (cmbSort.SelectedIndex)
            {
                case 1: return "StockQuantity ASC";
                case 2: return "StockQuantity DESC";
                case 3: return "Price ASC";
                case 4: return "Price DESC";
                case 5: return "DiscountPercent ASC";
                case 6: return "DiscountPercent DESC";
                default: return "ItemName ASC";
            }
        }

        private void RenderItems(DataView view)
        {
            flpItems.SuspendLayout();
            flpItems.Controls.Clear();

            foreach (DataRowView row in view)
            {
                flpItems.Controls.Add(CreateItemCard(row));
            }

            flpItems.ResumeLayout();
        }

        private Panel CreateItemCard(DataRowView row)
        {
            int itemId = Convert.ToInt32(row["ItemId"]);
            decimal price = Convert.ToDecimal(row["Price"]);
            decimal discount = Convert.ToDecimal(row["DiscountPercent"]);
            decimal finalPrice = Convert.ToDecimal(row["FinalPrice"]);
            int stock = Convert.ToInt32(row["StockQuantity"]);
            Color cardColor = Color.White;

            if (stock == 0) cardColor = Color.LightGray;
            else if (discount > 15) cardColor = Style.DiscountBackColor;

            Panel card = new Panel();
            card.Tag = itemId;
            card.Width = 915;
            card.Height = 136;
            card.Margin = new Padding(4, 4, 4, 10);
            card.BackColor = cardColor;
            card.Cursor = Cursors.Hand;
            card.Paint += ItemCard_Paint;
            card.Click += ItemCard_Click;
            card.DoubleClick += ItemCard_DoubleClick;

            PictureBox photo = new PictureBox();
            photo.Location = new Point(18, 14);
            photo.Size = new Size(185, 108);
            photo.SizeMode = PictureBoxSizeMode.Zoom;
            photo.BorderStyle = BorderStyle.FixedSingle;
            photo.BackColor = Color.White;
            string imagePath = ImageHelper.GetAbsoluteImagePath(Convert.ToString(row["ImagePath"]));
            if (File.Exists(imagePath)) photo.Image = Image.FromFile(imagePath);

            Panel infoPanel = new Panel();
            infoPanel.Location = new Point(215, 14);
            infoPanel.Size = new Size(520, 108);
            infoPanel.BackColor = Color.Transparent;
            infoPanel.BorderStyle = BorderStyle.FixedSingle;

            Color textColor = discount > 15 && stock != 0 ? Color.White : Color.Black;
            Label header = CreateLabel(Convert.ToString(row["CategoryName"]) + " | " + Convert.ToString(row["ItemName"]), 8, 6, 500, 20, true, textColor);
            Label description = CreateLabel("Описание товара: " + Convert.ToString(row["Description"]), 8, 28, 500, 18, false, textColor);
            Label manufacturer = CreateLabel("Производитель: " + Convert.ToString(row["ManufacturerName"]), 8, 46, 500, 18, false, textColor);
            Label supplier = CreateLabel("Поставщик: " + Convert.ToString(row["SupplierName"]), 8, 64, 500, 18, false, textColor);
            Label unit = CreateLabel("Единица измерения: " + Convert.ToString(row["UnitName"]), 8, 82, 240, 18, false, textColor);
            Label stockLabel = CreateLabel("Количество на складе: " + stock, 260, 82, 230, 18, false, textColor);

            infoPanel.Controls.Add(header);
            infoPanel.Controls.Add(description);
            infoPanel.Controls.Add(manufacturer);
            infoPanel.Controls.Add(supplier);
            infoPanel.Controls.Add(unit);
            infoPanel.Controls.Add(stockLabel);

            Label priceTitle = CreateLabel("Цена:", 745, 35, 55, 20, false, textColor);
            card.Controls.Add(priceTitle);

            if (discount > 0)
            {
                Label oldPrice = CreateLabel(price.ToString("0.00") + " руб.", 800, 35, 95, 20, false, Color.Red);
                oldPrice.Font = new Font("Arial", 9.5F, FontStyle.Strikeout);
                Label newPrice = CreateLabel(finalPrice.ToString("0.00") + " руб.", 800, 58, 100, 20, true, Color.Black);
                if (discount > 15 && stock != 0) newPrice.ForeColor = Color.White;
                card.Controls.Add(oldPrice);
                card.Controls.Add(newPrice);
            }
            else
            {
                Label normalPrice = CreateLabel(price.ToString("0.00") + " руб.", 800, 35, 100, 20, true, textColor);
                card.Controls.Add(normalPrice);
            }

            Panel discountPanel = new Panel();
            discountPanel.Location = new Point(750, 14);
            discountPanel.Size = new Size(145, 108);
            discountPanel.BorderStyle = BorderStyle.FixedSingle;
            discountPanel.BackColor = Color.Transparent;

            Label discountCaption = CreateLabel("Действующая", 12, 24, 120, 20, true, textColor);
            discountCaption.TextAlign = ContentAlignment.MiddleCenter;
            Label discountText = CreateLabel("скидка", 12, 44, 120, 18, true, textColor);
            discountText.TextAlign = ContentAlignment.MiddleCenter;
            Label discountValue = CreateLabel(discount.ToString("0.##") + "%", 12, 66, 120, 24, true, textColor);
            discountValue.TextAlign = ContentAlignment.MiddleCenter;
            discountPanel.Controls.Add(discountCaption);
            discountPanel.Controls.Add(discountText);
            discountPanel.Controls.Add(discountValue);

            card.Controls.Add(photo);
            card.Controls.Add(infoPanel);
            card.Controls.Add(discountPanel);

            BindItemCardEvents(card, card);
            return card;
        }

        private void BindItemCardEvents(Control parent, Panel card)
        {
            foreach (Control control in parent.Controls)
            {
                control.Cursor = Cursors.Hand;
                control.Click += (s, e) => OpenSelectedCard(card);
                control.DoubleClick += (s, e) => OpenSelectedCard(card);

                if (control.HasChildren)
                {
                    BindItemCardEvents(control, card);
                }
            }
        }

        private Label CreateLabel(string text, int x, int y, int width, int height, bool bold, Color color)
        {
            Label label = new Label();
            label.Text = text;
            label.Location = new Point(x, y);
            label.Size = new Size(width, height);
            label.ForeColor = color;
            label.Font = new Font("Arial", 9.5F, bold ? FontStyle.Bold : FontStyle.Regular);
            label.AutoEllipsis = true;
            label.BackColor = Color.Transparent;
            return label;
        }

        private void ItemCard_Paint(object sender, PaintEventArgs e)
        {
            Panel card = (Panel)sender;
            bool isSelected = Convert.ToInt32(card.Tag) == selectedItemId;
            using (Pen pen = new Pen(isSelected ? Style.AccentColor : Color.Black, isSelected ? 4 : 2))
            {
                e.Graphics.SmoothingMode = SmoothingMode.None;
                e.Graphics.DrawRectangle(pen, 1, 1, card.Width - 3, card.Height - 3);
            }
        }

        private void ItemCard_Click(object sender, EventArgs e)
        {
            OpenSelectedCard((Panel)sender);
        }

        private void ItemCard_DoubleClick(object sender, EventArgs e)
        {
            OpenSelectedCard((Panel)sender);
        }

        private void SelectItemCard(Panel card)
        {
            selectedItemId = Convert.ToInt32(card.Tag);
            foreach (Control control in flpItems.Controls) control.Invalidate();
        }

        private void OpenSelectedCard(Panel card)
        {
            SelectItemCard(card);
            if (Session.IsAdmin) OpenItemEdit(selectedItemId);
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            OpenItemEdit(null);
        }

        private void OpenItemEdit(int? itemId)
        {
            if (itemEditOpened)
            {
                MessageBox.Show("Окно редактирования товара уже открыто.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            itemEditOpened = true;
            using (ItemEditForm form = new ItemEditForm(itemId))
            {
                if (form.ShowDialog() == DialogResult.OK) LoadItems();
            }
            itemEditOpened = false;
        }

        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            if (selectedItemId == 0)
            {
                MessageBox.Show("Выберите товар в списке.", "Удаление товара", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int orderCount = Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM OrderItem WHERE ItemId = @id", new System.Data.SqlClient.SqlParameter("@id", selectedItemId)));
            if (orderCount > 0)
            {
                MessageBox.Show("Товар присутствует в заказе, поэтому удалить его нельзя.", "Удаление запрещено", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (MessageBox.Show("Удалить выбранный товар? Операцию нельзя отменить.", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            Db.Execute("DELETE FROM Item WHERE ItemId = @id", new System.Data.SqlClient.SqlParameter("@id", selectedItemId));
            LoadItems();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            using (OrderListForm form = new OrderListForm())
            {
                form.ShowDialog();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
