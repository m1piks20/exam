using System.Windows.Forms;
using System.Drawing;

namespace BicycleDrive
{
    partial class LoginForm
    {
        private TextBox txtLogin;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnGuest;
        private Label lblTitle;
        private Label lblLogin;
        private Label lblPassword;

        private void InitializeComponent()
        {
            txtLogin = new TextBox();
            txtPassword = new TextBox();
            btnLogin = new Button();
            btnGuest = new Button();
            lblTitle = new Label();
            lblLogin = new Label();
            lblPassword = new Label();

            SuspendLayout();
            lblTitle.Text = "Вход в систему";
            lblTitle.Font = new Font("Arial", 18F, FontStyle.Bold);
            lblTitle.Location = new Point(30, 25);
            lblTitle.Size = new Size(350, 40);

            lblLogin.Text = "Логин";
            lblLogin.Location = new Point(35, 90);
            lblLogin.Size = new Size(120, 25);
            txtLogin.Location = new Point(35, 115);
            txtLogin.Size = new Size(330, 30);

            lblPassword.Text = "Пароль";
            lblPassword.Location = new Point(35, 155);
            lblPassword.Size = new Size(120, 25);
            txtPassword.Location = new Point(35, 180);
            txtPassword.Size = new Size(330, 30);
            txtPassword.UseSystemPasswordChar = true;

            btnLogin.Text = "Войти";
            btnLogin.Location = new Point(35, 235);
            btnLogin.Size = new Size(155, 42);
            btnLogin.Click += btnLogin_Click;

            btnGuest.Text = "Войти как гость";
            btnGuest.Location = new Point(210, 235);
            btnGuest.Size = new Size(155, 42);
            btnGuest.Click += btnGuest_Click;

            ClientSize = new Size(400, 320);
            Controls.Add(lblTitle);
            Controls.Add(lblLogin);
            Controls.Add(txtLogin);
            Controls.Add(lblPassword);
            Controls.Add(txtPassword);
            Controls.Add(btnLogin);
            Controls.Add(btnGuest);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ВелосипедДрайв - вход";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
