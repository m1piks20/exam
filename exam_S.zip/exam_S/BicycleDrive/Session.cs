namespace BicycleDrive
{
    internal static class Session
    {
        public static int? UserId { get; set; }
        public static string FullName { get; set; }
        public static string RoleName { get; set; }

        public static bool IsGuest { get { return RoleName == "Гость"; } }
        public static bool IsClient { get { return RoleName == "Клиент"; } }
        public static bool IsManager { get { return RoleName == "Менеджер"; } }
        public static bool IsAdmin { get { return RoleName == "Администратор"; } }

        public static void SetGuest()
        {
            UserId = null;
            FullName = "Гость";
            RoleName = "Гость";
        }

        public static void Clear()
        {
            UserId = null;
            FullName = null;
            RoleName = null;
        }
    }
}
