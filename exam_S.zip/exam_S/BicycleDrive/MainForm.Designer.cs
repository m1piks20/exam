using System.Drawing;
using System.Windows.Forms;

namespace BicycleDrive
{
    partial class MainForm
    {
        private Label lblTitle;
        private Label lblUser;
        private PictureBox picLogo;
        private Button btnLogout;
        private Button btnAddItem;
        private Button btnDeleteItem;
        private Button btnOrders;
        private TextBox txtSearch;
        private ComboBox cmbDiscount;
        private ComboBox cmbSort;
        private FlowLayoutPanel flpItems;
        private Label lblSearch;
        private Label lblDiscount;
        private Label lblSort;

        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblUser = new Label();
            picLogo = new PictureBox();
            btnLogout = new Button();
            btnAddItem = new Button();
            btnDeleteItem = new Button();
            btnOrders = new Button();
            txtSearch = new TextBox();
            cmbDiscount = new ComboBox();
            cmbSort = new ComboBox();
            flpItems = new FlowLayoutPanel();
            lblSearch = new Label();
            lblDiscount = new Label();
            lblSort = new Label();
            ((System.ComponentModel.ISupportInitialize)(picLogo)).BeginInit();
            SuspendLayout();

            lblTitle.Text = "Список товаров";
            lblTitle.Font = new Font("Arial", 20F, FontStyle.Bold);
            lblTitle.Location = new Point(20, 15);
            lblTitle.Size = new Size(360, 40);

            picLogo.Location = new Point(20, 60);
            picLogo.Size = new Size(145, 65);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;

            lblUser.TextAlign = ContentAlignment.MiddleRight;
            lblUser.Location = new Point(590, 18);
            lblUser.Size = new Size(390, 25);

            btnLogout.Text = "Выйти";
            btnLogout.Location = new Point(870, 52);
            btnLogout.Size = new Size(110, 35);
            btnLogout.Click += btnLogout_Click;

            lblSearch.Text = "Поиск";
            lblSearch.Location = new Point(185, 68);
            lblSearch.Size = new Size(160, 20);
            txtSearch.Location = new Point(185, 92);
            txtSearch.Size = new Size(220, 30);
            txtSearch.TextChanged += FilterChanged;

            lblDiscount.Text = "Диапазон скидки";
            lblDiscount.Location = new Point(425, 68);
            lblDiscount.Size = new Size(160, 20);
            cmbDiscount.Location = new Point(425, 92);
            cmbDiscount.Size = new Size(170, 30);
            cmbDiscount.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDiscount.SelectedIndexChanged += FilterChanged;

            lblSort.Text = "Сортировка";
            lblSort.Location = new Point(615, 68);
            lblSort.Size = new Size(160, 20);
            cmbSort.Location = new Point(615, 92);
            cmbSort.Size = new Size(240, 30);
            cmbSort.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSort.SelectedIndexChanged += FilterChanged;

            btnOrders.Text = "Заказы";
            btnOrders.Location = new Point(20, 138);
            btnOrders.Size = new Size(120, 36);
            btnOrders.Click += btnOrders_Click;

            btnAddItem.Text = "Добавить товар";
            btnAddItem.Location = new Point(160, 138);
            btnAddItem.Size = new Size(155, 36);
            btnAddItem.Click += btnAddItem_Click;

            btnDeleteItem.Text = "Удалить товар";
            btnDeleteItem.Location = new Point(335, 138);
            btnDeleteItem.Size = new Size(155, 36);
            btnDeleteItem.Click += btnDeleteItem_Click;

            flpItems.Location = new Point(20, 185);
            flpItems.Size = new Size(960, 500);
            flpItems.AutoScroll = true;
            flpItems.FlowDirection = FlowDirection.TopDown;
            flpItems.WrapContents = false;
            flpItems.BackColor = Color.White;

            ClientSize = new Size(1005, 705);
            Controls.Add(lblTitle);
            Controls.Add(lblUser);
            Controls.Add(picLogo);
            Controls.Add(btnLogout);
            Controls.Add(lblSearch);
            Controls.Add(txtSearch);
            Controls.Add(lblDiscount);
            Controls.Add(cmbDiscount);
            Controls.Add(lblSort);
            Controls.Add(cmbSort);
            Controls.Add(btnOrders);
            Controls.Add(btnAddItem);
            Controls.Add(btnDeleteItem);
            Controls.Add(flpItems);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ВелосипедДрайв - товары";
            ((System.ComponentModel.ISupportInitialize)(picLogo)).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
