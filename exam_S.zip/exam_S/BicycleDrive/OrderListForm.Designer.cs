using System.Drawing;
using System.Windows.Forms;

namespace BicycleDrive
{
    partial class OrderListForm
    {
        private Label lblTitle;
        private FlowLayoutPanel flpOrders;
        private Button btnAddOrder;
        private Button btnDeleteOrder;
        private Button btnClose;

        private void InitializeComponent()
        {
            lblTitle = new Label();
            flpOrders = new FlowLayoutPanel();
            btnAddOrder = new Button();
            btnDeleteOrder = new Button();
            btnClose = new Button();

            SuspendLayout();
            lblTitle.Text = "Заказы";
            lblTitle.Font = new Font("Arial", 20F, FontStyle.Bold);
            lblTitle.Location = new Point(20, 15);
            lblTitle.Size = new Size(300, 40);

            btnAddOrder.Text = "Добавить заказ";
            btnAddOrder.Location = new Point(20, 65);
            btnAddOrder.Size = new Size(155, 36);
            btnAddOrder.Click += btnAddOrder_Click;

            btnDeleteOrder.Text = "Удалить заказ";
            btnDeleteOrder.Location = new Point(195, 65);
            btnDeleteOrder.Size = new Size(155, 36);
            btnDeleteOrder.Click += btnDeleteOrder_Click;

            btnClose.Text = "Назад";
            btnClose.Location = new Point(780, 65);
            btnClose.Size = new Size(110, 36);
            btnClose.Click += btnClose_Click;

            flpOrders.Location = new Point(20, 115);
            flpOrders.Size = new Size(870, 430);
            flpOrders.AutoScroll = true;
            flpOrders.FlowDirection = FlowDirection.TopDown;
            flpOrders.WrapContents = false;
            flpOrders.BackColor = Color.White;

            ClientSize = new Size(915, 570);
            Controls.Add(lblTitle);
            Controls.Add(btnAddOrder);
            Controls.Add(btnDeleteOrder);
            Controls.Add(btnClose);
            Controls.Add(flpOrders);
            StartPosition = FormStartPosition.CenterParent;
            Text = "Заказы";
            ResumeLayout(false);
        }
    }
}
