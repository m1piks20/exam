Демонстрационный экзамен: WinForms .NET Framework 4.7.2 + SQL Server Management Studio 18

Сущности названы нейтрально: Item, AppUser, RoleEntity, OrderHeader, OrderLine, PickupPoint, OrderStatus.
Предметную область можно заменить без переименования таблиц.

Порядок запуска:
1. Откройте SSMS 18.
2. Подключитесь к .\SQLEXPRESS или к своему SQL Server.
3. Откройте Sql\CreateDatabase.sql и выполните весь скрипт.
4. Откройте NeutralTradeExam.sln в Visual Studio.
5. Если сервер не .\SQLEXPRESS, измените строку подключения в NeutralTradeExam\App.config.
6. Запустите проект.

Тестовые пользователи есть в таблице AppUser. Пароли хранятся как PasswordText, чтобы на экзамене было проще проверить авторизацию.

Основные файлы:
- Program.cs: старт приложения.
- App.config: строка подключения.
- Db.cs: универсальные методы работы с SQL Server через ADO.NET.
- AppState.cs: текущий пользователь и проверка роли.
- Ui.cs: единый стиль: Times New Roman, цвета #FFFFFF, #7FFF00, #00FA9A и #2E8B57.
- LoginForm.cs + LoginForm.Designer.cs: форма входа и гостевой вход.
- MainForm.cs + MainForm.Designer.cs: список товаров, фильтрация/поиск/сортировка, список заказов и разграничение прав.
- ItemEditForm.cs + ItemEditForm.Designer.cs: добавление и редактирование сущности Item.
- OrderEditForm.cs + OrderEditForm.Designer.cs: добавление и редактирование заказов и состава заказа.
- Resources: логотип, иконка, изображения товаров.

Роли:
- Гость: просмотр товаров без фильтрации, сортировки и поиска.
- Клиент: просмотр товаров без фильтрации, сортировки и поиска.
- Менеджер: просмотр товаров с фильтрацией/сортировкой/поиском, просмотр заказов.
- Администратор: все функции менеджера + добавление/изменение/удаление товаров и заказов.
