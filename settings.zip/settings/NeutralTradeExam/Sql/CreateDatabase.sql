﻿IF DB_ID(N'TradeExamNeutal322') IS NOT NULL
BEGIN
    ALTER DATABASE TradeExamNeutral SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE TradeExamNeutral;
END
GO
CREATE DATABASE TradeExamNeutral;
GO
USE TradeExamNeutral;
GO
CREATE TABLE RoleEntity1 (
    Id INT IDENTITY(1,1) CONSTRAINT PK_RoleEntity PRIMARY KEY,
    Title NVARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE AppUser2 (
    Id INT IDENTITY(1,1) CONSTRAINT PK_AppUser PRIMARY KEY,
    RoleId INT NOT NULL CONSTRAINT FK_AppUser_RoleEntity REFERENCES RoleEntity(Id),
    FullName NVARCHAR(150) NOT NULL,
    Login NVARCHAR(100) NOT NULL UNIQUE,
    PasswordText NVARCHAR(100) NOT NULL
);
CREATE TABLE Item3 (
    Id INT IDENTITY(1,1) CONSTRAINT PK_Item PRIMARY KEY,
    Article NVARCHAR(30) NOT NULL UNIQUE,
    Title NVARCHAR(200) NOT NULL,
    Unit NVARCHAR(20) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Supplier NVARCHAR(150) NULL,
    Producer NVARCHAR(150) NULL,
    Category NVARCHAR(100) NULL,
    Discount INT NOT NULL DEFAULT 0,
    Quantity INT NOT NULL DEFAULT 0,
    Description NVARCHAR(MAX) NULL,
    ImagePath NVARCHAR(260) NULL
);
CREATE TABLE PickupPoint4 (
    Id INT IDENTITY(1,1) CONSTRAINT PK_PickupPoint PRIMARY KEY,
    AddressText NVARCHAR(250) NOT NULL
);
CREATE TABLE OrderStatus5 (
    Id INT IDENTITY(1,1) CONSTRAINT PK_OrderStatus PRIMARY KEY,
    Title NVARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE OrderHeader6 (
    Id INT NOT NULL CONSTRAINT PK_OrderHeader PRIMARY KEY,
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NULL,
    PickupPointId INT NOT NULL CONSTRAINT FK_OrderHeader_PickupPoint REFERENCES PickupPoint(Id),
    AppUserId INT NULL CONSTRAINT FK_OrderHeader_AppUser REFERENCES AppUser(Id),
    ReceiveCode INT NOT NULL,
    StatusId INT NOT NULL CONSTRAINT FK_OrderHeader_OrderStatus REFERENCES OrderStatus(Id)
);
CREATE TABLE OrderLine7 (
    Id INT IDENTITY(1,1) CONSTRAINT PK_OrderLine PRIMARY KEY,
    OrderId INT NOT NULL CONSTRAINT FK_OrderLine_OrderHeader REFERENCES OrderHeader(Id) ON DELETE CASCADE,
    ItemId INT NOT NULL CONSTRAINT FK_OrderLine_Item REFERENCES Item(Id),
    Quantity INT NOT NULL CHECK (Quantity > 0)
);
GO

INSERT INTO RoleEntity(Title) VALUES (N'Авторизированный клиент');
INSERT INTO RoleEntity(Title) VALUES (N'Администратор');
INSERT INTO RoleEntity(Title) VALUES (N'Менеджер');
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Никифорова Весения Николаевна', N'94d5ous@gmail.com', N'uzWC67' FROM RoleEntity WHERE Title=N'Администратор';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Сазонов Руслан Германович', N'uth4iz@mail.com', N'2L6KZG' FROM RoleEntity WHERE Title=N'Администратор';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Одинцов Серафим Артёмович', N'yzls62@outlook.com', N'JlFRCZ' FROM RoleEntity WHERE Title=N'Администратор';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Степанов Михаил Артёмович', N'1diph5e@tutanota.com', N'8ntwUp' FROM RoleEntity WHERE Title=N'Менеджер';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Ворсин Петр Евгеньевич', N'tjde7c@yahoo.com', N'YOyhfR' FROM RoleEntity WHERE Title=N'Менеджер';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Старикова Елена Павловна', N'wpmrc3do@tutanota.com', N'RSbvHv' FROM RoleEntity WHERE Title=N'Менеджер';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Михайлюк Анна Вячеславовна', N'5d4zbu@tutanota.com', N'rwVDh9' FROM RoleEntity WHERE Title=N'Авторизированный клиент';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Ситдикова Елена Анатольевна', N'ptec8ym@yahoo.com', N'LdNyos' FROM RoleEntity WHERE Title=N'Авторизированный клиент';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Ворсин Петр Евгеньевич', N'1qz4kw@mail.com', N'gynQMT' FROM RoleEntity WHERE Title=N'Авторизированный клиент';
INSERT INTO AppUser(RoleId, FullName, Login, PasswordText) SELECT Id, N'Старикова Елена Павловна', N'4np6se@mail.com', N'AtnDjr' FROM RoleEntity WHERE Title=N'Авторизированный клиент';
INSERT INTO OrderStatus(Title) VALUES (N'Завершен');
INSERT INTO OrderStatus(Title) VALUES (N'Новый ');
INSERT INTO PickupPoint(AddressText) VALUES (N'420151, г. Лесной, ул. Вишневая, 32');
INSERT INTO PickupPoint(AddressText) VALUES (N'125061, г. Лесной, ул. Подгорная, 8');
INSERT INTO PickupPoint(AddressText) VALUES (N'630370, г. Лесной, ул. Шоссейная, 24');
INSERT INTO PickupPoint(AddressText) VALUES (N'400562, г. Лесной, ул. Зеленая, 32');
INSERT INTO PickupPoint(AddressText) VALUES (N'614510, г. Лесной, ул. Маяковского, 47');
INSERT INTO PickupPoint(AddressText) VALUES (N'410542, г. Лесной, ул. Светлая, 46');
INSERT INTO PickupPoint(AddressText) VALUES (N'620839, г. Лесной, ул. Цветочная, 8');
INSERT INTO PickupPoint(AddressText) VALUES (N'443890, г. Лесной, ул. Коммунистическая, 1');
INSERT INTO PickupPoint(AddressText) VALUES (N'603379, г. Лесной, ул. Спортивная, 46');
INSERT INTO PickupPoint(AddressText) VALUES (N'603721, г. Лесной, ул. Гоголя, 41');
INSERT INTO PickupPoint(AddressText) VALUES (N'410172, г. Лесной, ул. Северная, 13');
INSERT INTO PickupPoint(AddressText) VALUES (N'614611, г. Лесной, ул. Молодежная, 50');
INSERT INTO PickupPoint(AddressText) VALUES (N'454311, г.Лесной, ул. Новая, 19');
INSERT INTO PickupPoint(AddressText) VALUES (N'660007, г.Лесной, ул. Октябрьская, 19');
INSERT INTO PickupPoint(AddressText) VALUES (N'603036, г. Лесной, ул. Садовая, 4');
INSERT INTO PickupPoint(AddressText) VALUES (N'394060, г.Лесной, ул. Фрунзе, 43');
INSERT INTO PickupPoint(AddressText) VALUES (N'410661, г. Лесной, ул. Школьная, 50');
INSERT INTO PickupPoint(AddressText) VALUES (N'625590, г. Лесной, ул. Коммунистическая, 20');
INSERT INTO PickupPoint(AddressText) VALUES (N'625683, г. Лесной, ул. 8 Марта');
INSERT INTO PickupPoint(AddressText) VALUES (N'450983, г.Лесной, ул. Комсомольская, 26');
INSERT INTO PickupPoint(AddressText) VALUES (N'394782, г. Лесной, ул. Чехова, 3');
INSERT INTO PickupPoint(AddressText) VALUES (N'603002, г. Лесной, ул. Дзержинского, 28');
INSERT INTO PickupPoint(AddressText) VALUES (N'450558, г. Лесной, ул. Набережная, 30');
INSERT INTO PickupPoint(AddressText) VALUES (N'344288, г. Лесной, ул. Чехова, 1');
INSERT INTO PickupPoint(AddressText) VALUES (N'614164, г.Лесной,  ул. Степная, 30');
INSERT INTO PickupPoint(AddressText) VALUES (N'394242, г. Лесной, ул. Коммунистическая, 43');
INSERT INTO PickupPoint(AddressText) VALUES (N'660540, г. Лесной, ул. Солнечная, 25');
INSERT INTO PickupPoint(AddressText) VALUES (N'125837, г. Лесной, ул. Шоссейная, 40');
INSERT INTO PickupPoint(AddressText) VALUES (N'125703, г. Лесной, ул. Партизанская, 49');
INSERT INTO PickupPoint(AddressText) VALUES (N'625283, г. Лесной, ул. Победы, 46');
INSERT INTO PickupPoint(AddressText) VALUES (N'614753, г. Лесной, ул. Полевая, 35');
INSERT INTO PickupPoint(AddressText) VALUES (N'426030, г. Лесной, ул. Маяковского, 44');
INSERT INTO PickupPoint(AddressText) VALUES (N'450375, г. Лесной ул. Клубная, 44');
INSERT INTO PickupPoint(AddressText) VALUES (N'625560, г. Лесной, ул. Некрасова, 12');
INSERT INTO PickupPoint(AddressText) VALUES (N'630201, г. Лесной, ул. Комсомольская, 17');
INSERT INTO PickupPoint(AddressText) VALUES (N'190949, г. Лесной, ул. Мичурина, 26');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'А112Т4', N'Ботинки', N'шт.', 4990.0, N'Kari', N'Kari', N'Женская обувь', 3, 6, N'Женские Ботинки демисезонные kari', N'1.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'F635R4', N'Ботинки', N'шт.', 3244.0, N'Обувь для вас', N'Marco Tozzi', N'Женская обувь', 2, 13, N'Ботинки Marco Tozzi женские демисезонные, размер 39, цвет бежевый', N'2.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'H782T5', N'Туфли', N'шт.', 4499.0, N'Kari', N'Kari', N'Мужская обувь', 4, 5, N'Туфли kari мужские классика MYZ21AW-450A, размер 43, цвет: черный', N'3.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'G783F5', N'Ботинки', N'шт.', 5900.0, N'Kari', N'Рос', N'Мужская обувь', 2, 8, N'Мужские ботинки Рос-Обувь кожаные с натуральным мехом', N'4.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'J384T6', N'Ботинки', N'шт.', 3800.0, N'Обувь для вас', N'Rieker', N'Мужская обувь', 2, 16, N'B3430/14 Полуботинки мужские Rieker', N'5.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'D572U8', N'Кроссовки', N'шт.', 4100.0, N'Обувь для вас', N'Рос', N'Мужская обувь', 3, 6, N'129615-4 Кроссовки мужские', N'6.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'F572H7', N'Туфли', N'шт.', 2700.0, N'Kari', N'Marco Tozzi', N'Женская обувь', 2, 14, N'Туфли Marco Tozzi женские летние, размер 39, цвет черный', N'7.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'D329H3', N'Полуботинки', N'шт.', 1890.0, N'Обувь для вас', N'Alessio Nesca', N'Женская обувь', 4, 4, N'Полуботинки Alessio Nesca женские 3-30797-47, размер 37, цвет: бордовый', N'8.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'B320R5', N'Туфли', N'шт.', 4300.0, N'Kari', N'Rieker', N'Женская обувь', 2, 6, N'Туфли Rieker женские демисезонные, размер 41, цвет коричневый', N'9.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'G432E4', N'Туфли', N'шт.', 2800.0, N'Kari', N'Kari', N'Женская обувь', 3, 15, N'Туфли kari женские TR-YR-413017, размер 37, цвет: черный', N'10.jpg');
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'S213E3', N'Полуботинки', N'шт.', 2156.0, N'Обувь для вас', N'CROSBY', N'Мужская обувь', 3, 6, N'407700/01-01 Полуботинки мужские CROSBY', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'E482R4', N'Полуботинки', N'шт.', 1800.0, N'Kari', N'Kari', N'Женская обувь', 2, 14, N'Полуботинки kari женские MYZ20S-149, размер 41, цвет: черный', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'S634B5', N'Кеды', N'шт.', 5500.0, N'Обувь для вас', N'CROSBY', N'Мужская обувь', 3, 0, N'Кеды Caprice мужские демисезонные, размер 42, цвет черный', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'K345R4', N'Полуботинки', N'шт.', 2100.0, N'Обувь для вас', N'CROSBY', N'Мужская обувь', 2, 3, N'407700/01-02 Полуботинки мужские CROSBY', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'O754F4', N'Туфли', N'шт.', 5400.0, N'Обувь для вас', N'Rieker', N'Женская обувь', 4, 18, N'Туфли женские демисезонные Rieker артикул 55073-68/37', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'G531F4', N'Ботинки', N'шт.', 6600.0, N'Kari', N'Kari', N'Женская обувь', 12, 9, N'Ботинки женские зимние ROMER арт. 893167-01 Черный', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'J542F5', N'Тапочки', N'шт.', 500.0, N'Kari', N'Kari', N'Мужская обувь', 13, 0, N'Тапочки мужские Арт.70701-55-67син р.41', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'B431R5', N'Ботинки', N'шт.', 2700.0, N'Обувь для вас', N'Rieker', N'Мужская обувь', 2, 5, N'Мужские кожаные ботинки/мужские ботинки', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'P764G4', N'Туфли', N'шт.', 6800.0, N'Kari', N'CROSBY', N'Женская обувь', 15, 15, N'Туфли женские, ARGO, размер 38', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'C436G5', N'Ботинки', N'шт.', 10200.0, N'Kari', N'Alessio Nesca', N'Женская обувь', 15, 9, N'Ботинки женские, ARGO, размер 40', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'F427R5', N'Ботинки', N'шт.', 11800.0, N'Обувь для вас', N'Rieker', N'Женская обувь', 15, 11, N'Ботинки на молнии с декоративной пряжкой FRAU', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'N457T5', N'Полуботинки', N'шт.', 4600.0, N'Kari', N'CROSBY', N'Женская обувь', 3, 13, N'Полуботинки Ботинки черные зимние, мех', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'D364R4', N'Туфли', N'шт.', 12400.0, N'Kari', N'Kari', N'Женская обувь', 16, 5, N'Туфли Luiza Belly женские Kate-lazo черные из натуральной замши', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'S326R5', N'Тапочки', N'шт.', 9900.0, N'Обувь для вас', N'CROSBY', N'Мужская обувь', 17, 15, N'Мужские кожаные тапочки "Профиль С.Дали" ', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'L754R4', N'Полуботинки', N'шт.', 1700.0, N'Kari', N'Kari', N'Женская обувь', 2, 7, N'Полуботинки kari женские WB2020SS-26, размер 38, цвет: черный', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'M542T5', N'Кроссовки', N'шт.', 2800.0, N'Обувь для вас', N'Rieker', N'Мужская обувь', 18, 3, N'Кроссовки мужские TOFA', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'D268G5', N'Туфли', N'шт.', 4399.0, N'Обувь для вас', N'Rieker', N'Женская обувь', 3, 12, N'Туфли Rieker женские демисезонные, размер 36, цвет коричневый', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'T324F5', N'Сапоги', N'шт.', 4699.0, N'Kari', N'CROSBY', N'Женская обувь', 2, 5, N'Сапоги замша Цвет: синий', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'K358H6', N'Тапочки', N'шт.', 599.0, N'Kari', N'Rieker', N'Мужская обувь', 20, 2, N'Тапочки мужские син р.41', NULL);
INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES (N'H535R5', N'Ботинки', N'шт.', 2300.0, N'Обувь для вас', N'Rieker', N'Женская обувь', 2, 7, N'Женские Ботинки демисезонные', NULL);
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 1, '2025-02-27', '2025-04-20', 1, u.Id, 901, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Степанов Михаил Артёмович' AND s.Title=N'Завершен';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 2, '2022-09-28', '2025-04-21', 11, u.Id, 902, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Никифорова Весения Николаевна' AND s.Title=N'Завершен';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 3, '2025-03-21', '2025-04-22', 2, u.Id, 903, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Сазонов Руслан Германович' AND s.Title=N'Завершен';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 4, '2025-02-20', '2025-04-23', 11, u.Id, 904, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Одинцов Серафим Артёмович' AND s.Title=N'Завершен';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 5, '2025-03-17', '2025-04-24', 2, u.Id, 905, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Степанов Михаил Артёмович' AND s.Title=N'Завершен';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 6, '2025-03-01', '2025-04-25', 15, u.Id, 906, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Никифорова Весения Николаевна' AND s.Title=N'Завершен';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 7, N'30.02.2025', '2025-04-26', 3, u.Id, 907, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Сазонов Руслан Германович' AND s.Title=N'Завершен';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 8, '2025-03-31', '2025-04-27', 19, u.Id, 908, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Одинцов Серафим Артёмович' AND s.Title=N'Новый ';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 9, '2025-04-02', '2025-04-28', 5, u.Id, 909, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Степанов Михаил Артёмович' AND s.Title=N'Новый ';
INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) SELECT 10, '2025-04-03', '2025-04-29', 19, u.Id, 910, s.Id FROM AppUser u CROSS JOIN OrderStatus s WHERE u.FullName=N'Степанов Михаил Артёмович' AND s.Title=N'Новый ';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 1, Id, 2 FROM Item WHERE Article=N'А112Т4';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 1, Id, 2 FROM Item WHERE Article=N'F635R4';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 2, Id, 1 FROM Item WHERE Article=N'H782T5';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 2, Id, 1 FROM Item WHERE Article=N'G783F5';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 3, Id, 10 FROM Item WHERE Article=N'J384T6';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 3, Id, 10 FROM Item WHERE Article=N'D572U8';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 4, Id, 5 FROM Item WHERE Article=N'F572H7';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 4, Id, 4 FROM Item WHERE Article=N'D329H3';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 5, Id, 2 FROM Item WHERE Article=N'А112Т4';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 5, Id, 2 FROM Item WHERE Article=N'F635R4';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 6, Id, 1 FROM Item WHERE Article=N'H782T5';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 6, Id, 1 FROM Item WHERE Article=N'G783F5';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 7, Id, 10 FROM Item WHERE Article=N'J384T6';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 7, Id, 10 FROM Item WHERE Article=N'D572U8';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 8, Id, 5 FROM Item WHERE Article=N'F572H7';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 8, Id, 4 FROM Item WHERE Article=N'D329H3';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 9, Id, 5 FROM Item WHERE Article=N'B320R5';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 9, Id, 1 FROM Item WHERE Article=N'G432E4';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 10, Id, 5 FROM Item WHERE Article=N'S213E3';
INSERT INTO OrderLine(OrderId, ItemId, Quantity) SELECT 10, Id, 5 FROM Item WHERE Article=N'E482R4';