using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace NeutralTradeExam
{
    public static class Db
    {
        private static string ConnString { get { return ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString; } }

        public static DataTable Table(string sql, params SqlParameter[] pars)
        {
            using (var con = new SqlConnection(ConnString))
            using (var cmd = new SqlCommand(sql, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                if (pars != null) cmd.Parameters.AddRange(pars);
                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static object Scalar(string sql, params SqlParameter[] pars)
        {
            using (var con = new SqlConnection(ConnString))
            using (var cmd = new SqlCommand(sql, con))
            {
                if (pars != null) cmd.Parameters.AddRange(pars);
                con.Open();
                return cmd.ExecuteScalar();
            }
        }

        public static int Exec(string sql, params SqlParameter[] pars)
        {
            using (var con = new SqlConnection(ConnString))
            using (var cmd = new SqlCommand(sql, con))
            {
                if (pars != null) cmd.Parameters.AddRange(pars);
                con.Open();
                return cmd.ExecuteNonQuery();
            }
        }
    }
}
