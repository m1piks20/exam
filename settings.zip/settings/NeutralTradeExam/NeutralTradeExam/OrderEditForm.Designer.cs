namespace NeutralTradeExam
{
    partial class OrderEditForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.NumericUpDown idNumeric;
        private System.Windows.Forms.DateTimePicker orderDatePicker;
        private System.Windows.Forms.DateTimePicker deliveryDatePicker;
        private System.Windows.Forms.ComboBox pickupComboBox;
        private System.Windows.Forms.ComboBox userComboBox;
        private System.Windows.Forms.NumericUpDown codeNumeric;
        private System.Windows.Forms.ComboBox statusComboBox;
        private System.Windows.Forms.Label idLabel;
        private System.Windows.Forms.Label orderDateLabel;
        private System.Windows.Forms.Label deliveryDateLabel;
        private System.Windows.Forms.Label pickupLabel;
        private System.Windows.Forms.Label userLabel;
        private System.Windows.Forms.Label codeLabel;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Label lineLabel;
        private System.Windows.Forms.ComboBox itemComboBox;
        private System.Windows.Forms.NumericUpDown quantityNumeric;
        private System.Windows.Forms.Button addLineButton;
        private System.Windows.Forms.Button removeLineButton;
        private System.Windows.Forms.DataGridView linesGrid;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button cancelButton;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.idNumeric = new System.Windows.Forms.NumericUpDown();
            this.orderDatePicker = new System.Windows.Forms.DateTimePicker();
            this.deliveryDatePicker = new System.Windows.Forms.DateTimePicker();
            this.pickupComboBox = new System.Windows.Forms.ComboBox();
            this.userComboBox = new System.Windows.Forms.ComboBox();
            this.codeNumeric = new System.Windows.Forms.NumericUpDown();
            this.statusComboBox = new System.Windows.Forms.ComboBox();
            this.idLabel = new System.Windows.Forms.Label();
            this.orderDateLabel = new System.Windows.Forms.Label();
            this.deliveryDateLabel = new System.Windows.Forms.Label();
            this.pickupLabel = new System.Windows.Forms.Label();
            this.userLabel = new System.Windows.Forms.Label();
            this.codeLabel = new System.Windows.Forms.Label();
            this.statusLabel = new System.Windows.Forms.Label();
            this.lineLabel = new System.Windows.Forms.Label();
            this.itemComboBox = new System.Windows.Forms.ComboBox();
            this.quantityNumeric = new System.Windows.Forms.NumericUpDown();
            this.addLineButton = new System.Windows.Forms.Button();
            this.removeLineButton = new System.Windows.Forms.Button();
            this.linesGrid = new System.Windows.Forms.DataGridView();
            this.saveButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.idNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.codeNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.linesGrid)).BeginInit();
            this.SuspendLayout();
            this.idLabel.SetBounds(20, 22, 120, 23); this.idLabel.Text = "Номер";
            this.orderDateLabel.SetBounds(20, 57, 120, 23); this.orderDateLabel.Text = "Дата заказа";
            this.deliveryDateLabel.SetBounds(20, 92, 120, 23); this.deliveryDateLabel.Text = "Дата доставки";
            this.pickupLabel.SetBounds(20, 127, 120, 23); this.pickupLabel.Text = "Пункт выдачи";
            this.userLabel.SetBounds(20, 162, 120, 23); this.userLabel.Text = "Клиент";
            this.codeLabel.SetBounds(20, 197, 120, 23); this.codeLabel.Text = "Код";
            this.statusLabel.SetBounds(20, 232, 120, 23); this.statusLabel.Text = "Статус";
            this.idNumeric.SetBounds(155, 18, 280, 23); this.idNumeric.Maximum = 1000000;
            this.orderDatePicker.SetBounds(155, 53, 280, 23);
            this.deliveryDatePicker.SetBounds(155, 88, 280, 23);
            this.pickupComboBox.SetBounds(155, 123, 280, 23); this.pickupComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.userComboBox.SetBounds(155, 158, 280, 23); this.userComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.codeNumeric.SetBounds(155, 193, 280, 23); this.codeNumeric.Maximum = 999999;
            this.statusComboBox.SetBounds(155, 228, 280, 23); this.statusComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lineLabel.SetBounds(20, 270, 140, 23); this.lineLabel.Text = "Состав заказа";
            this.itemComboBox.SetBounds(155, 266, 280, 23); this.itemComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.quantityNumeric.SetBounds(445, 266, 70, 23); this.quantityNumeric.Minimum = 1; this.quantityNumeric.Maximum = 10000; this.quantityNumeric.Value = 1;
            this.addLineButton.SetBounds(525, 263, 90, 28); this.addLineButton.Text = "Добавить"; this.addLineButton.Click += new System.EventHandler(this.addLineButton_Click);
            this.removeLineButton.SetBounds(625, 263, 90, 28); this.removeLineButton.Text = "Удалить"; this.removeLineButton.Click += new System.EventHandler(this.removeLineButton_Click);
            this.linesGrid.SetBounds(20, 305, 695, 180); this.linesGrid.AllowUserToAddRows = false; this.linesGrid.ReadOnly = true; this.linesGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect; this.linesGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.saveButton.SetBounds(455, 505, 120, 32); this.saveButton.Text = "Сохранить"; this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            this.cancelButton.SetBounds(595, 505, 120, 32); this.cancelButton.Text = "Отмена"; this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Controls.Add(this.idLabel); this.Controls.Add(this.orderDateLabel); this.Controls.Add(this.deliveryDateLabel); this.Controls.Add(this.pickupLabel);
            this.Controls.Add(this.userLabel); this.Controls.Add(this.codeLabel); this.Controls.Add(this.statusLabel); this.Controls.Add(this.lineLabel);
            this.Controls.Add(this.idNumeric); this.Controls.Add(this.orderDatePicker); this.Controls.Add(this.deliveryDatePicker); this.Controls.Add(this.pickupComboBox); this.Controls.Add(this.userComboBox); this.Controls.Add(this.codeNumeric); this.Controls.Add(this.statusComboBox); this.Controls.Add(this.itemComboBox); this.Controls.Add(this.quantityNumeric); this.Controls.Add(this.addLineButton); this.Controls.Add(this.removeLineButton); this.Controls.Add(this.linesGrid); this.Controls.Add(this.saveButton); this.Controls.Add(this.cancelButton);
            this.ClientSize = new System.Drawing.Size(745, 560);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "OrderEditForm";
            this.Text = "Редактирование заказа";
            ((System.ComponentModel.ISupportInitialize)(this.idNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.codeNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.linesGrid)).EndInit();
            this.ResumeLayout(false);
        }
    }
}
