namespace NeutralTradeExam
{
    partial class ItemEditForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox articleTextBox;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.TextBox unitTextBox;
        private System.Windows.Forms.NumericUpDown priceNumeric;
        private System.Windows.Forms.TextBox supplierTextBox;
        private System.Windows.Forms.TextBox producerTextBox;
        private System.Windows.Forms.TextBox categoryTextBox;
        private System.Windows.Forms.NumericUpDown discountNumeric;
        private System.Windows.Forms.NumericUpDown quantityNumeric;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.TextBox imageTextBox;
        private System.Windows.Forms.Button browseImageButton;
        private System.Windows.Forms.PictureBox imagePreviewBox;
        private System.Windows.Forms.Label articleLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label unitLabel;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label supplierLabel;
        private System.Windows.Forms.Label producerLabel;
        private System.Windows.Forms.Label categoryLabel;
        private System.Windows.Forms.Label discountLabel;
        private System.Windows.Forms.Label quantityLabel;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.Label imageLabel;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.OpenFileDialog openImageDialog;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.articleTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.unitTextBox = new System.Windows.Forms.TextBox();
            this.priceNumeric = new System.Windows.Forms.NumericUpDown();
            this.supplierTextBox = new System.Windows.Forms.TextBox();
            this.producerTextBox = new System.Windows.Forms.TextBox();
            this.categoryTextBox = new System.Windows.Forms.TextBox();
            this.discountNumeric = new System.Windows.Forms.NumericUpDown();
            this.quantityNumeric = new System.Windows.Forms.NumericUpDown();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.imageTextBox = new System.Windows.Forms.TextBox();
            this.browseImageButton = new System.Windows.Forms.Button();
            this.imagePreviewBox = new System.Windows.Forms.PictureBox();
            this.articleLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.unitLabel = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.supplierLabel = new System.Windows.Forms.Label();
            this.producerLabel = new System.Windows.Forms.Label();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.discountLabel = new System.Windows.Forms.Label();
            this.quantityLabel = new System.Windows.Forms.Label();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.imageLabel = new System.Windows.Forms.Label();
            this.saveButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.openImageDialog = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.priceNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.discountNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityNumeric)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagePreviewBox)).BeginInit();
            this.SuspendLayout();
            this.articleLabel.SetBounds(20, 22, 120, 23); this.articleLabel.Text = "Артикул";
            this.titleLabel.SetBounds(20, 57, 120, 23); this.titleLabel.Text = "Наименование";
            this.unitLabel.SetBounds(20, 92, 120, 23); this.unitLabel.Text = "Ед. измерения";
            this.priceLabel.SetBounds(20, 127, 120, 23); this.priceLabel.Text = "Цена";
            this.supplierLabel.SetBounds(20, 162, 120, 23); this.supplierLabel.Text = "Поставщик";
            this.producerLabel.SetBounds(20, 197, 120, 23); this.producerLabel.Text = "Производитель";
            this.categoryLabel.SetBounds(20, 232, 120, 23); this.categoryLabel.Text = "Категория";
            this.discountLabel.SetBounds(20, 267, 120, 23); this.discountLabel.Text = "Скидка";
            this.quantityLabel.SetBounds(20, 302, 120, 23); this.quantityLabel.Text = "Кол-во";
            this.descriptionLabel.SetBounds(20, 337, 120, 23); this.descriptionLabel.Text = "Описание";
            this.imageLabel.SetBounds(20, 407, 120, 23); this.imageLabel.Text = "Фото";
            this.articleTextBox.SetBounds(160, 18, 280, 23);
            this.titleTextBox.SetBounds(160, 53, 280, 23);
            this.unitTextBox.SetBounds(160, 88, 280, 23);
            this.priceNumeric.SetBounds(160, 123, 280, 23); this.priceNumeric.Maximum = 1000000; this.priceNumeric.DecimalPlaces = 2;
            this.supplierTextBox.SetBounds(160, 158, 280, 23);
            this.producerTextBox.SetBounds(160, 193, 280, 23);
            this.categoryTextBox.SetBounds(160, 228, 280, 23);
            this.discountNumeric.SetBounds(160, 263, 280, 23); this.discountNumeric.Maximum = 100;
            this.quantityNumeric.SetBounds(160, 298, 280, 23); this.quantityNumeric.Maximum = 100000;
            this.descriptionTextBox.SetBounds(160, 333, 280, 55); this.descriptionTextBox.Multiline = true;
            this.imageTextBox.SetBounds(160, 403, 210, 23);
            this.imageTextBox.TextChanged += new System.EventHandler(this.imageTextBox_TextChanged);
            this.browseImageButton.SetBounds(380, 403, 60, 23);
            this.browseImageButton.Text = "...";
            this.browseImageButton.Click += new System.EventHandler(this.browseImageButton_Click);
            this.imagePreviewBox.SetBounds(470, 18, 220, 220);
            this.imagePreviewBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imagePreviewBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.saveButton.SetBounds(160, 445, 120, 32); this.saveButton.Text = "Сохранить"; this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            this.cancelButton.SetBounds(320, 445, 120, 32); this.cancelButton.Text = "Отмена"; this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Controls.Add(this.articleLabel); this.Controls.Add(this.titleLabel); this.Controls.Add(this.unitLabel); this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.supplierLabel); this.Controls.Add(this.producerLabel); this.Controls.Add(this.categoryLabel); this.Controls.Add(this.discountLabel);
            this.Controls.Add(this.quantityLabel); this.Controls.Add(this.descriptionLabel); this.Controls.Add(this.imageLabel);
            this.Controls.Add(this.articleTextBox); this.Controls.Add(this.titleTextBox); this.Controls.Add(this.unitTextBox); this.Controls.Add(this.priceNumeric);
            this.Controls.Add(this.supplierTextBox); this.Controls.Add(this.producerTextBox); this.Controls.Add(this.categoryTextBox); this.Controls.Add(this.discountNumeric);
            this.Controls.Add(this.quantityNumeric); this.Controls.Add(this.descriptionTextBox); this.Controls.Add(this.imageTextBox);
            this.Controls.Add(this.browseImageButton); this.Controls.Add(this.imagePreviewBox); this.Controls.Add(this.saveButton); this.Controls.Add(this.cancelButton);
            this.ClientSize = new System.Drawing.Size(715, 500);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "ItemEditForm";
            this.Text = "Редактирование товара";
            ((System.ComponentModel.ISupportInitialize)(this.priceNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.discountNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityNumeric)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagePreviewBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
