using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace NeutralTradeExam
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            Ui.Apply(this);
            enterButton.BackColor = Ui.Accent;
            guestButton.BackColor = Ui.ExtraBack;
            try { logoBox.Image = Image.FromFile("Resources\\Logo.png"); } catch { }
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(loginTextBox.Text) || string.IsNullOrWhiteSpace(passwordTextBox.Text))
            {
                MessageBox.Show("Введите логин и пароль.");
                return;
            }

            var dt = Db.Table(@"SELECT TOP 1 u.Id, u.FullName, r.Title AS RoleTitle
                                FROM AppUser u INNER JOIN RoleEntity r ON r.Id = u.RoleId
                                WHERE u.Login = @login AND u.PasswordText = @password",
                new SqlParameter("@login", loginTextBox.Text.Trim()),
                new SqlParameter("@password", passwordTextBox.Text.Trim()));

            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Неверный логин или пароль.");
                return;
            }

            AppState.UserId = Convert.ToInt32(dt.Rows[0]["Id"]);
            AppState.FullName = Convert.ToString(dt.Rows[0]["FullName"]);
            AppState.Role = Convert.ToString(dt.Rows[0]["RoleTitle"]);
            OpenMain();
        }

        private void guestButton_Click(object sender, EventArgs e)
        {
            AppState.AsGuest();
            OpenMain();
        }

        private void OpenMain()
        {
            Hide();
            using (var f = new MainForm()) f.ShowDialog();
            Show();
            passwordTextBox.Clear();
        }
    }
}
