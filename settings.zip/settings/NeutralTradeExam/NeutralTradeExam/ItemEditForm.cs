using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace NeutralTradeExam
{
    public partial class ItemEditForm : Form
    {
        private readonly int? itemId;

        public ItemEditForm(int? id)
        {
            itemId = id;
            InitializeComponent();
            Ui.Apply(this);
            saveButton.BackColor = Ui.Accent;
            cancelButton.BackColor = Ui.ExtraBack;
            Text = id.HasValue ? "Изменение товара" : "Добавление товара";
            if (id.HasValue) LoadItem(id.Value);
            else unitTextBox.Text = "шт.";
            ShowPreview();
        }

        private void LoadItem(int id)
        {
            var dt = Db.Table("SELECT * FROM Item WHERE Id=@id", new SqlParameter("@id", id));
            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];
            articleTextBox.Text = Convert.ToString(r["Article"]);
            titleTextBox.Text = Convert.ToString(r["Title"]);
            unitTextBox.Text = Convert.ToString(r["Unit"]);
            priceNumeric.Value = Convert.ToDecimal(r["Price"]);
            supplierTextBox.Text = Convert.ToString(r["Supplier"]);
            producerTextBox.Text = Convert.ToString(r["Producer"]);
            categoryTextBox.Text = Convert.ToString(r["Category"]);
            discountNumeric.Value = Convert.ToDecimal(r["Discount"]);
            quantityNumeric.Value = Convert.ToDecimal(r["Quantity"]);
            descriptionTextBox.Text = Convert.ToString(r["Description"]);
            imageTextBox.Text = Convert.ToString(r["ImagePath"]);
            ShowPreview();
        }


        private void imageTextBox_TextChanged(object sender, EventArgs e)
        {
            ShowPreview();
        }

        private void browseImageButton_Click(object sender, EventArgs e)
        {
            openImageDialog.Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp|Все файлы|*.*";
            if (openImageDialog.ShowDialog() != DialogResult.OK) return;

            try
            {
                string imagesFolder = Path.Combine(Application.StartupPath, "Resources", "ProductImages");
                Directory.CreateDirectory(imagesFolder);

                string fileName = Path.GetFileName(openImageDialog.FileName);
                string destination = Path.Combine(imagesFolder, fileName);

                if (!File.Exists(destination) || !SameFile(openImageDialog.FileName, destination))
                    File.Copy(openImageDialog.FileName, destination, true);

                imageTextBox.Text = fileName;
                ShowPreview();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось выбрать фото: " + ex.Message);
            }
        }

        private bool SameFile(string firstPath, string secondPath)
        {
            return string.Equals(Path.GetFullPath(firstPath).TrimEnd('\\'), Path.GetFullPath(secondPath).TrimEnd('\\'), StringComparison.OrdinalIgnoreCase);
        }

        private void ShowPreview()
        {
            if (imagePreviewBox == null) return;

            if (imagePreviewBox.Image != null)
            {
                var old = imagePreviewBox.Image;
                imagePreviewBox.Image = null;
                old.Dispose();
            }

            string imageName = imageTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(imageName)) return;

            string path = imageName;
            if (!Path.IsPathRooted(path))
                path = Path.Combine(Application.StartupPath, "Resources", "ProductImages", imageName);

            if (!File.Exists(path)) return;

            try
            {
                using (var temp = Image.FromFile(path))
                {
                    imagePreviewBox.Image = new Bitmap(temp);
                }
            }
            catch
            {
                imagePreviewBox.Image = null;
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(articleTextBox.Text) || string.IsNullOrWhiteSpace(titleTextBox.Text))
            {
                MessageBox.Show("Заполните артикул и наименование.");
                return;
            }

            string sql = itemId.HasValue
                ? @"UPDATE Item SET Article=@article, Title=@title, Unit=@unit, Price=@price, Supplier=@supplier, Producer=@producer, Category=@category, Discount=@discount, Quantity=@quantity, Description=@description, ImagePath=@image WHERE Id=@id"
                : @"INSERT INTO Item(Article,Title,Unit,Price,Supplier,Producer,Category,Discount,Quantity,Description,ImagePath) VALUES(@article,@title,@unit,@price,@supplier,@producer,@category,@discount,@quantity,@description,@image)";
            var pars = new System.Collections.Generic.List<SqlParameter>
            {
                new SqlParameter("@article", articleTextBox.Text.Trim()),
                new SqlParameter("@title", titleTextBox.Text.Trim()),
                new SqlParameter("@unit", unitTextBox.Text.Trim()),
                new SqlParameter("@price", priceNumeric.Value),
                new SqlParameter("@supplier", supplierTextBox.Text.Trim()),
                new SqlParameter("@producer", producerTextBox.Text.Trim()),
                new SqlParameter("@category", categoryTextBox.Text.Trim()),
                new SqlParameter("@discount", discountNumeric.Value),
                new SqlParameter("@quantity", quantityNumeric.Value),
                new SqlParameter("@description", descriptionTextBox.Text.Trim()),
                new SqlParameter("@image", imageTextBox.Text.Trim())
            };
            if (itemId.HasValue) pars.Add(new SqlParameter("@id", itemId.Value));
            try
            {
                Db.Exec(sql, pars.ToArray());
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex) { MessageBox.Show("Ошибка сохранения: " + ex.Message); }
        }
    }
}
