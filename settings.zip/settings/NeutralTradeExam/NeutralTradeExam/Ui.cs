using System.Drawing;
using System.Windows.Forms;

namespace NeutralTradeExam
{
    public static class Ui
    {
        public static readonly Color MainBack = Color.White;
        public static readonly Color ExtraBack = ColorTranslator.FromHtml("#7FFF00");
        public static readonly Color Accent = ColorTranslator.FromHtml("#00FA9A");
        public static readonly Color DiscountBack = ColorTranslator.FromHtml("#2E8B57");

        public static void Apply(Form form)
        {
            form.BackColor = MainBack;
            form.Font = new Font("Times New Roman", 10F);
            form.StartPosition = FormStartPosition.CenterScreen;
            try { form.Icon = new Icon("Resources\\AppIcon.ico"); } catch { }
        }

        public static Button AccentButton(string text)
        {
            return new Button { Text = text, BackColor = Accent, FlatStyle = FlatStyle.Flat, Height = 32, Width = 130 };
        }
    }
}
