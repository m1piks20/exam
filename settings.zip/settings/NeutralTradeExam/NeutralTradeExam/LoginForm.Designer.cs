namespace NeutralTradeExam
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.PictureBox logoBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label loginLabel;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.TextBox loginTextBox;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.Button guestButton;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.logoBox = new System.Windows.Forms.PictureBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.loginLabel = new System.Windows.Forms.Label();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.loginTextBox = new System.Windows.Forms.TextBox();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.enterButton = new System.Windows.Forms.Button();
            this.guestButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logoBox)).BeginInit();
            this.SuspendLayout();
            this.logoBox.Location = new System.Drawing.Point(20, 15);
            this.logoBox.Name = "logoBox";
            this.logoBox.Size = new System.Drawing.Size(86, 70);
            this.logoBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold);
            this.titleLabel.Location = new System.Drawing.Point(125, 35);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(277, 25);
            this.titleLabel.Text = "Вход в систему ООО «Обувь»";
            this.loginLabel.AutoSize = true;
            this.loginLabel.Location = new System.Drawing.Point(55, 115);
            this.loginLabel.Text = "Логин";
            this.loginTextBox.Location = new System.Drawing.Point(150, 112);
            this.loginTextBox.Size = new System.Drawing.Size(250, 23);
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Location = new System.Drawing.Point(55, 155);
            this.passwordLabel.Text = "Пароль";
            this.passwordTextBox.Location = new System.Drawing.Point(150, 152);
            this.passwordTextBox.Size = new System.Drawing.Size(250, 23);
            this.passwordTextBox.UseSystemPasswordChar = true;
            this.enterButton.Location = new System.Drawing.Point(150, 200);
            this.enterButton.Size = new System.Drawing.Size(120, 34);
            this.enterButton.Text = "Войти";
            this.enterButton.UseVisualStyleBackColor = false;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            this.guestButton.Location = new System.Drawing.Point(280, 200);
            this.guestButton.Size = new System.Drawing.Size(120, 34);
            this.guestButton.Text = "Гость";
            this.guestButton.UseVisualStyleBackColor = false;
            this.guestButton.Click += new System.EventHandler(this.guestButton_Click);
            this.AcceptButton = this.enterButton;
            this.ClientSize = new System.Drawing.Size(460, 270);
            this.Controls.Add(this.logoBox);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.loginLabel);
            this.Controls.Add(this.loginTextBox);
            this.Controls.Add(this.passwordLabel);
            this.Controls.Add(this.passwordTextBox);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.guestButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "LoginForm";
            this.Text = "Авторизация";
            ((System.ComponentModel.ISupportInitialize)(this.logoBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
