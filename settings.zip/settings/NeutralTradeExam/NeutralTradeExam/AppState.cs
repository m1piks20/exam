namespace NeutralTradeExam
{
    public static class AppState
    {
        public static int? UserId { get; set; }
        public static string FullName { get; set; }
        public static string Role { get; set; }
        public static bool IsGuest { get { return string.IsNullOrWhiteSpace(Role); } }
        public static bool IsAdmin { get { return Role == "Администратор"; } }
        public static bool IsManager { get { return Role == "Менеджер"; } }
        public static bool IsClient { get { return Role == "Клиент"; } }

        public static void AsGuest()
        {
            UserId = null;
            FullName = "Гость";
            Role = null;
        }
    }
}
