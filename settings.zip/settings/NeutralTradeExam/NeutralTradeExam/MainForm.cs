using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace NeutralTradeExam
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            Ui.Apply(this);
            try { logoBox.Image = Image.FromFile("Resources\\Logo.png"); } catch { }
            exitButton.BackColor = Ui.Accent;
            addItemButton.BackColor = editItemButton.BackColor = deleteItemButton.BackColor = Ui.Accent;
            addOrderButton.BackColor = editOrderButton.BackColor = deleteOrderButton.BackColor = Ui.Accent;
            userLabel.Text = "Пользователь: " + AppState.FullName + "    Роль: " + (AppState.IsGuest ? "Гость" : AppState.Role);
            ConfigureAccess();
            LoadCategories();
            sortComboBox.Items.AddRange(new object[] { "Без сортировки", "Цена по возрастанию", "Цена по убыванию", "Скидка по возрастанию", "Скидка по убыванию" });
            sortComboBox.SelectedIndex = 0;
            LoadItems();
            LoadOrders();
        }

        private void ConfigureAccess()
        {
            bool canFilter = AppState.IsManager || AppState.IsAdmin;
            searchTextBox.Visible = categoryComboBox.Visible = sortComboBox.Visible = canFilter;
            addItemButton.Visible = editItemButton.Visible = deleteItemButton.Visible = AppState.IsAdmin;
            ordersTab.Parent = (AppState.IsManager || AppState.IsAdmin) ? tabControl : null;
            addOrderButton.Visible = editOrderButton.Visible = deleteOrderButton.Visible = AppState.IsAdmin;
        }

        private void LoadCategories()
        {
            categoryComboBox.Items.Clear();
            categoryComboBox.Items.Add("Все категории");
            foreach (DataRow r in Db.Table("SELECT DISTINCT Category FROM Item WHERE Category IS NOT NULL ORDER BY Category").Rows)
                categoryComboBox.Items.Add(Convert.ToString(r[0]));
            categoryComboBox.SelectedIndex = 0;
            searchTextBox.Text = "";
        }

        private void LoadItems()
        {
            string sql = @"SELECT Id, Article AS [Артикул], Title AS [Наименование], Unit AS [Ед.], Price AS [Цена], Supplier AS [Поставщик], Producer AS [Производитель], Category AS [Категория], Discount AS [Скидка], Quantity AS [На складе], Description AS [Описание], ImagePath AS [Фото]
                           FROM Item WHERE 1=1";
            var pars = new System.Collections.Generic.List<SqlParameter>();
            if (AppState.IsManager || AppState.IsAdmin)
            {
                if (!string.IsNullOrWhiteSpace(searchTextBox.Text))
                {
                    sql += " AND (Article LIKE @q OR Title LIKE @q OR Description LIKE @q OR Supplier LIKE @q OR Producer LIKE @q)";
                    pars.Add(new SqlParameter("@q", "%" + searchTextBox.Text.Trim() + "%"));
                }
                if (categoryComboBox.SelectedIndex > 0)
                {
                    sql += " AND Category = @cat";
                    pars.Add(new SqlParameter("@cat", categoryComboBox.Text));
                }
                if (sortComboBox.Text == "Цена по возрастанию") sql += " ORDER BY Price ASC";
                else if (sortComboBox.Text == "Цена по убыванию") sql += " ORDER BY Price DESC";
                else if (sortComboBox.Text == "Скидка по возрастанию") sql += " ORDER BY Discount ASC";
                else if (sortComboBox.Text == "Скидка по убыванию") sql += " ORDER BY Discount DESC";
                else sql += " ORDER BY Id";
            }
            else sql += " ORDER BY Id";

            DataTable table = Db.Table(sql, pars.ToArray());
            itemsGrid.DataSource = table;
            ConfigureItemsGridView();
            AddCatalogImageColumn();
            FillCatalogImages();
            ShowSelectedItemImage();
        }


        private void AddCatalogImageColumn()
        {
            // Каждый раз создаем колонку заново.
            // Так мы не зависим от того, какой тип колонки DataGridView создал автоматически.
            if (itemsGrid.Columns.Contains("Картинка"))
                itemsGrid.Columns.Remove("Картинка");

            DataGridViewImageColumn catalogImageColumn = new DataGridViewImageColumn();
            catalogImageColumn.Name = "Картинка";
            catalogImageColumn.HeaderText = "Фото";
            catalogImageColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
            catalogImageColumn.Width = 105;
            catalogImageColumn.FillWeight = 60;

            itemsGrid.Columns.Insert(0, catalogImageColumn);
        }

        private void FillCatalogImages()
        {
            if (!itemsGrid.Columns.Contains("Картинка") || !itemsGrid.Columns.Contains("Фото"))
                return;

            foreach (DataGridViewRow row in itemsGrid.Rows)
            {
                if (row.IsNewRow) continue;

                string imageName = Convert.ToString(row.Cells["Фото"].Value);
                row.Cells["Картинка"].Value = LoadItemThumbnail(imageName, 90, 70);
            }
        }

        private Image LoadItemThumbnail(string imageName, int width, int height)
        {
            try
            {
                string path = Path.Combine(
                    Application.StartupPath,
                    "Resources",
                    "ProductImages",
                    imageName);

                if (!File.Exists(path))
                    throw new FileNotFoundException();

                using (var img = Image.FromFile(path))
                {
                    return new Bitmap(img, new Size(width, height));
                }
            }
            catch
            {
                string logoPath = Path.Combine(
                    Application.StartupPath,
                    "Resources",
                    "Logo.png");

                if (File.Exists(logoPath))
                {
                    using (var img = Image.FromFile(logoPath))
                    {
                        return new Bitmap(img, new Size(width, height));
                    }
                }

                return new Bitmap(width, height);
            }
        }

        private void ConfigureItemsGridView()
        {
            if (itemsGrid.Columns.Contains("Id")) itemsGrid.Columns["Id"].Visible = false;
            if (itemsGrid.Columns.Contains("Фото")) itemsGrid.Columns["Фото"].Visible = false;

            itemsGrid.RowTemplate.Height = 82;
            foreach (DataGridViewRow row in itemsGrid.Rows)
                row.Height = 82;

            if (itemsGrid.Columns.Contains("Описание"))
                itemsGrid.Columns["Описание"].Visible = false;

            if (itemsGrid.Columns.Contains("Наименование"))
                itemsGrid.Columns["Наименование"].FillWeight = 160;
        }

        private void LoadOrders()
        {
            if (!(AppState.IsManager || AppState.IsAdmin)) return;
            ordersGrid.DataSource = Db.Table(@"SELECT h.Id AS [Номер], h.OrderDate AS [Дата заказа], h.DeliveryDate AS [Дата доставки], p.AddressText AS [Пункт выдачи], u.FullName AS [Клиент], h.ReceiveCode AS [Код], s.Title AS [Статус],
                        STUFF((SELECT ', ' + i.Article + ' x' + CAST(l.Quantity AS NVARCHAR(10)) FROM OrderLine l INNER JOIN Item i ON i.Id=l.ItemId WHERE l.OrderId=h.Id FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'),1,2,'') AS [Состав]
                        FROM OrderHeader h
                        INNER JOIN PickupPoint p ON p.Id=h.PickupPointId
                        LEFT JOIN AppUser u ON u.Id=h.AppUserId
                        INNER JOIN OrderStatus s ON s.Id=h.StatusId
                        ORDER BY h.Id");
        }

        private int SelectedId(DataGridView grid, string columnName)
        {
            if (grid.CurrentRow == null) return 0;
            return Convert.ToInt32(grid.CurrentRow.Cells[columnName].Value);
        }

        private void itemFilter_Changed(object sender, EventArgs e) { if (sortComboBox.SelectedIndex >= 0) LoadItems(); }
        private void refreshItemsButton_Click(object sender, EventArgs e) { LoadCategories(); LoadItems(); }
        private void refreshOrdersButton_Click(object sender, EventArgs e) { LoadOrders(); }
        private void exitButton_Click(object sender, EventArgs e) { Close(); }

        private void addItemButton_Click(object sender, EventArgs e)
        {
            using (var f = new ItemEditForm(null)) if (f.ShowDialog() == DialogResult.OK) { LoadCategories(); LoadItems(); }
        }

        private void editItemButton_Click(object sender, EventArgs e)
        {
            int id = SelectedId(itemsGrid, "Id");
            if (id == 0) return;
            using (var f = new ItemEditForm(id)) if (f.ShowDialog() == DialogResult.OK) { LoadCategories(); LoadItems(); }
        }

        private void deleteItemButton_Click(object sender, EventArgs e)
        {
            int id = SelectedId(itemsGrid, "Id");
            if (id == 0) return;
            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try { Db.Exec("DELETE FROM Item WHERE Id=@id", new SqlParameter("@id", id)); LoadItems(); }
                catch (Exception ex) { MessageBox.Show("Удаление невозможно: " + ex.Message); }
            }
        }

        private void addOrderButton_Click(object sender, EventArgs e)
        {
            using (var f = new OrderEditForm(null)) if (f.ShowDialog() == DialogResult.OK) LoadOrders();
        }

        private void editOrderButton_Click(object sender, EventArgs e)
        {
            int id = SelectedId(ordersGrid, "Номер");
            if (id == 0) return;
            using (var f = new OrderEditForm(id)) if (f.ShowDialog() == DialogResult.OK) LoadOrders();
        }

        private void deleteOrderButton_Click(object sender, EventArgs e)
        {
            int id = SelectedId(ordersGrid, "Номер");
            if (id == 0) return;
            if (MessageBox.Show("Удалить выбранный заказ?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Db.Exec("DELETE FROM OrderHeader WHERE Id=@id", new SqlParameter("@id", id));
                LoadOrders();
            }
        }


        private void itemsGrid_SelectionChanged(object sender, EventArgs e)
        {
            ShowSelectedItemImage();
        }

        private void ShowSelectedItemImage()
        {
            if (itemsGrid.CurrentRow == null || !itemsGrid.Columns.Contains("Фото"))
            {
                SetItemImage(null, "Выберите товар в таблице");
                return;
            }

            string imageName = Convert.ToString(itemsGrid.CurrentRow.Cells["Фото"].Value);
            if (string.IsNullOrWhiteSpace(imageName))
            {
                SetItemImage(null, "Для этого товара фото не указано");
                return;
            }

            string path = imageName;
            if (!Path.IsPathRooted(path))
                path = Path.Combine(Application.StartupPath, "Resources", "ProductImages", imageName);

            if (!File.Exists(path))
            {
                SetItemImage(null, "Файл не найден: " + imageName);
                return;
            }

            try
            {
                using (var temp = Image.FromFile(path))
                {
                    SetItemImage(new Bitmap(temp), imageName);
                }
            }
            catch
            {
                SetItemImage(null, "Не удалось открыть фото: " + imageName);
            }
        }

        private void SetItemImage(Image image, string text)
        {
            if (itemImageBox.Image != null)
            {
                var old = itemImageBox.Image;
                itemImageBox.Image = null;
                old.Dispose();
            }
            itemImageBox.Image = image;
            itemPhotoPathLabel.Text = text;
        }

        private void itemsGrid_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            var row = itemsGrid.Rows[e.RowIndex];
            if (itemsGrid.Columns.Contains("Скидка") && row.Cells["Скидка"].Value != DBNull.Value)
            {
                int discount = Convert.ToInt32(row.Cells["Скидка"].Value);
                if (discount > 15) row.DefaultCellStyle.BackColor = Ui.DiscountBack;
            }
        }
    }
}
