using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace NeutralTradeExam
{
    public partial class OrderEditForm : Form
    {
        private readonly int? orderId;
        private readonly DataTable lines = new DataTable();

        public OrderEditForm(int? id)
        {
            orderId = id;
            InitializeComponent();
            Ui.Apply(this);
            saveButton.BackColor = addLineButton.BackColor = removeLineButton.BackColor = Ui.Accent;
            cancelButton.BackColor = Ui.ExtraBack;
            Text = id.HasValue ? "Изменение заказа" : "Добавление заказа";
            PrepareLines();
            LoadDictionaries();
            if (id.HasValue) LoadOrder(id.Value);
            else
            {
                idNumeric.Value = Convert.ToDecimal(Db.Scalar("SELECT ISNULL(MAX(Id),0)+1 FROM OrderHeader"));
                codeNumeric.Value = 100;
            }
        }

        private void PrepareLines()
        {
            lines.Columns.Add("ItemId", typeof(int));
            lines.Columns.Add("Артикул", typeof(string));
            lines.Columns.Add("Наименование", typeof(string));
            lines.Columns.Add("Количество", typeof(int));
            linesGrid.DataSource = lines;
            if (linesGrid.Columns.Contains("ItemId")) linesGrid.Columns["ItemId"].Visible = false;
        }

        private void LoadDictionaries()
        {
            pickupComboBox.DataSource = Db.Table("SELECT Id, AddressText FROM PickupPoint ORDER BY Id");
            pickupComboBox.DisplayMember = "AddressText"; pickupComboBox.ValueMember = "Id";
            userComboBox.DataSource = Db.Table("SELECT Id, FullName FROM AppUser ORDER BY FullName");
            userComboBox.DisplayMember = "FullName"; userComboBox.ValueMember = "Id";
            statusComboBox.DataSource = Db.Table("SELECT Id, Title FROM OrderStatus ORDER BY Id");
            statusComboBox.DisplayMember = "Title"; statusComboBox.ValueMember = "Id";
            itemComboBox.DataSource = Db.Table("SELECT Id, Article + ' - ' + Title AS DisplayText, Article, Title FROM Item ORDER BY Article");
            itemComboBox.DisplayMember = "DisplayText"; itemComboBox.ValueMember = "Id";
        }

        private void LoadOrder(int id)
        {
            var h = Db.Table("SELECT * FROM OrderHeader WHERE Id=@id", new SqlParameter("@id", id));
            if (h.Rows.Count == 0) return;
            var r = h.Rows[0];
            idNumeric.Value = id; idNumeric.Enabled = false;
            orderDatePicker.Value = Convert.ToDateTime(r["OrderDate"]);
            deliveryDatePicker.Value = Convert.ToDateTime(r["DeliveryDate"]);
            pickupComboBox.SelectedValue = Convert.ToInt32(r["PickupPointId"]);
            userComboBox.SelectedValue = Convert.ToInt32(r["AppUserId"]);
            codeNumeric.Value = Convert.ToDecimal(r["ReceiveCode"]);
            statusComboBox.SelectedValue = Convert.ToInt32(r["StatusId"]);
            var dt = Db.Table(@"SELECT l.ItemId, i.Article AS [Артикул], i.Title AS [Наименование], l.Quantity AS [Количество]
                                FROM OrderLine l INNER JOIN Item i ON i.Id=l.ItemId WHERE l.OrderId=@id", new SqlParameter("@id", id));
            foreach (DataRow row in dt.Rows) lines.ImportRow(row);
        }

        private void addLineButton_Click(object sender, EventArgs e)
        {
            if (itemComboBox.SelectedValue == null) return;
            int itemId = Convert.ToInt32(itemComboBox.SelectedValue);
            var dt = Db.Table("SELECT Article, Title FROM Item WHERE Id=@id", new SqlParameter("@id", itemId));
            if (dt.Rows.Count == 0) return;
            lines.Rows.Add(itemId, Convert.ToString(dt.Rows[0]["Article"]), Convert.ToString(dt.Rows[0]["Title"]), Convert.ToInt32(quantityNumeric.Value));
        }

        private void removeLineButton_Click(object sender, EventArgs e)
        {
            if (linesGrid.CurrentRow != null) linesGrid.Rows.Remove(linesGrid.CurrentRow);
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            if (lines.Rows.Count == 0)
            {
                MessageBox.Show("Добавьте хотя бы одну позицию в заказ.");
                return;
            }
            int id = Convert.ToInt32(idNumeric.Value);
            try
            {
                if (orderId.HasValue)
                    Db.Exec(@"UPDATE OrderHeader SET OrderDate=@od, DeliveryDate=@dd, PickupPointId=@pp, AppUserId=@u, ReceiveCode=@c, StatusId=@s WHERE Id=@id",
                        P("@od", orderDatePicker.Value.Date), P("@dd", deliveryDatePicker.Value.Date), P("@pp", pickupComboBox.SelectedValue), P("@u", userComboBox.SelectedValue), P("@c", codeNumeric.Value), P("@s", statusComboBox.SelectedValue), P("@id", id));
                else
                    Db.Exec(@"INSERT INTO OrderHeader(Id,OrderDate,DeliveryDate,PickupPointId,AppUserId,ReceiveCode,StatusId) VALUES(@id,@od,@dd,@pp,@u,@c,@s)",
                        P("@id", id), P("@od", orderDatePicker.Value.Date), P("@dd", deliveryDatePicker.Value.Date), P("@pp", pickupComboBox.SelectedValue), P("@u", userComboBox.SelectedValue), P("@c", codeNumeric.Value), P("@s", statusComboBox.SelectedValue));
                Db.Exec("DELETE FROM OrderLine WHERE OrderId=@id", P("@id", id));
                foreach (DataRow row in lines.Rows)
                    Db.Exec("INSERT INTO OrderLine(OrderId, ItemId, Quantity) VALUES(@o,@i,@q)", P("@o", id), P("@i", row["ItemId"]), P("@q", row["Количество"]));
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex) { MessageBox.Show("Ошибка сохранения: " + ex.Message); }
        }

        private SqlParameter P(string name, object value) { return new SqlParameter(name, value ?? DBNull.Value); }
    }
}
