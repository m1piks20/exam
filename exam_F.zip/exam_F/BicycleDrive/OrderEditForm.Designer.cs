using System.Windows.Forms;
using System.Drawing;

namespace BicycleDrive
{
    partial class OrderEditForm
    {
        private Label lblTitle;
        private Label lblArticles;
        private Label lblStatus;
        private Label lblPickupPoint;
        private Label lblOrderDate;
        private Label lblDeliveryDate;
        private Label lblCustomerName;
        private Label lblReceiveCode;
        private ComboBox cmbStatus;
        private ComboBox cmbPickupPoint;
        private DateTimePicker dtOrderDate;
        private DateTimePicker dtDeliveryDate;
        private TextBox txtArticles;
        private TextBox txtCustomerName;
        private TextBox txtReceiveCode;
        private Button btnSave;
        private Button btnCancel;

        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblArticles = new Label();
            lblStatus = new Label();
            lblPickupPoint = new Label();
            lblOrderDate = new Label();
            lblDeliveryDate = new Label();
            lblCustomerName = new Label();
            lblReceiveCode = new Label();
            cmbStatus = new ComboBox();
            cmbPickupPoint = new ComboBox();
            dtOrderDate = new DateTimePicker();
            dtDeliveryDate = new DateTimePicker();
            txtArticles = new TextBox();
            txtCustomerName = new TextBox();
            txtReceiveCode = new TextBox();
            btnSave = new Button();
            btnCancel = new Button();

            SuspendLayout();
            lblTitle.Text = "Заказ";
            lblTitle.Font = new Font("Arial", 16F, FontStyle.Bold);
            lblTitle.Location = new Point(20, 15);
            lblTitle.Size = new Size(500, 35);

            lblArticles.Text = "Артикулы и количество: A112T4, 2, G843H5, 1";
            lblArticles.Location = new Point(20, 60);
            lblArticles.Size = new Size(610, 22);
            txtArticles.Location = new Point(20, 85);
            txtArticles.Size = new Size(610, 25);

            lblStatus.Text = "Статус заказа";
            lblStatus.Location = new Point(20, 120);
            lblStatus.Size = new Size(250, 22);
            cmbStatus.Location = new Point(20, 145);
            cmbStatus.Size = new Size(250, 25);
            cmbStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            lblPickupPoint.Text = "Пункт выдачи";
            lblPickupPoint.Location = new Point(300, 120);
            lblPickupPoint.Size = new Size(330, 22);
            cmbPickupPoint.Location = new Point(300, 145);
            cmbPickupPoint.Size = new Size(330, 25);
            cmbPickupPoint.DropDownStyle = ComboBoxStyle.DropDownList;

            lblOrderDate.Text = "Дата заказа";
            lblOrderDate.Location = new Point(20, 180);
            lblOrderDate.Size = new Size(190, 22);
            dtOrderDate.Location = new Point(20, 205);
            dtOrderDate.Size = new Size(190, 25);

            lblDeliveryDate.Text = "Дата выдачи";
            lblDeliveryDate.Location = new Point(235, 180);
            lblDeliveryDate.Size = new Size(190, 22);
            dtDeliveryDate.Location = new Point(235, 205);
            dtDeliveryDate.Size = new Size(190, 25);

            lblCustomerName.Text = "ФИО клиента";
            lblCustomerName.Location = new Point(20, 240);
            lblCustomerName.Size = new Size(300, 22);
            txtCustomerName.Location = new Point(20, 265);
            txtCustomerName.Size = new Size(300, 25);

            lblReceiveCode.Text = "Код получения";
            lblReceiveCode.Location = new Point(350, 240);
            lblReceiveCode.Size = new Size(150, 22);
            txtReceiveCode.Location = new Point(350, 265);
            txtReceiveCode.Size = new Size(150, 25);

            btnSave.Text = "Сохранить";
            btnSave.Location = new Point(410, 320);
            btnSave.Size = new Size(105, 35);
            btnSave.Click += btnSave_Click;

            btnCancel.Text = "Отмена";
            btnCancel.Location = new Point(525, 320);
            btnCancel.Size = new Size(105, 35);
            btnCancel.Click += btnCancel_Click;

            ClientSize = new Size(660, 380);
            Controls.Add(lblTitle);
            Controls.Add(lblArticles);
            Controls.Add(lblStatus);
            Controls.Add(lblPickupPoint);
            Controls.Add(lblOrderDate);
            Controls.Add(lblDeliveryDate);
            Controls.Add(lblCustomerName);
            Controls.Add(lblReceiveCode);
            Controls.Add(txtArticles);
            Controls.Add(cmbStatus);
            Controls.Add(cmbPickupPoint);
            Controls.Add(dtOrderDate);
            Controls.Add(dtDeliveryDate);
            Controls.Add(txtCustomerName);
            Controls.Add(txtReceiveCode);
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            StartPosition = FormStartPosition.CenterParent;
            Text = "Заказ";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
