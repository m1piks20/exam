using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BicycleDrive
{
    public partial class OrderEditForm : Form
    {
        private readonly int? orderId;

        public OrderEditForm(int? orderId)
        {
            this.orderId = orderId;
            InitializeComponent();
            Style.Apply(this);
            Style.AccentButton(btnSave);
            Text = orderId.HasValue ? "Редактирование заказа" : "Добавление заказа";
            lblTitle.Text = Text;
            LoadDictionaries();
            if (orderId.HasValue) LoadOrder();
        }

        private void LoadDictionaries()
        {
            cmbStatus.DataSource = Db.Query("SELECT OrderStatusId, StatusName FROM OrderStatus ORDER BY StatusName");
            cmbStatus.DisplayMember = "StatusName";
            cmbStatus.ValueMember = "OrderStatusId";

            cmbPickupPoint.DataSource = Db.Query("SELECT PickupPointId, AddressText FROM PickupPoint ORDER BY PickupPointId");
            cmbPickupPoint.DisplayMember = "AddressText";
            cmbPickupPoint.ValueMember = "PickupPointId";
        }

        private void LoadOrder()
        {
            DataTable table = Db.Query("SELECT * FROM OrderHeader WHERE OrderId = @id", new SqlParameter("@id", orderId.Value));
            if (table.Rows.Count == 0) return;

            DataRow row = table.Rows[0];
            cmbStatus.SelectedValue = row["OrderStatusId"];
            cmbPickupPoint.SelectedValue = row["PickupPointId"];
            dtOrderDate.Value = Convert.ToDateTime(row["OrderDate"]);
            dtDeliveryDate.Value = Convert.ToDateTime(row["DeliveryDate"]);
            txtCustomerName.Text = Convert.ToString(row["CustomerName"]);
            txtReceiveCode.Text = Convert.ToString(row["ReceiveCode"]);

            DataTable items = Db.Query(@"SELECT i.Article, oi.Quantity FROM OrderItem oi JOIN Item i ON i.ItemId=oi.ItemId WHERE oi.OrderId=@id",
                new SqlParameter("@id", orderId.Value));

            List<string> parts = new List<string>();
            foreach (DataRow item in items.Rows)
            {
                parts.Add(Convert.ToString(item["Article"]));
                parts.Add(Convert.ToString(item["Quantity"]));
            }
            txtArticles.Text = string.Join(", ", parts);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int code;
            if (!int.TryParse(txtReceiveCode.Text, out code))
            {
                MessageBox.Show("Код получения должен быть целым числом.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<Tuple<string, int>> orderItems;
            if (!TryParseItems(out orderItems)) return;

            int id;
            if (orderId.HasValue)
            {
                id = orderId.Value;
                Db.Execute(@"UPDATE OrderHeader SET OrderDate=@orderDate, DeliveryDate=@deliveryDate, PickupPointId=@pickup,
                             CustomerName=@customer, ReceiveCode=@code, OrderStatusId=@status WHERE OrderId=@id",
                    HeaderParams(code, new SqlParameter("@id", id)));
                Db.Execute("DELETE FROM OrderItem WHERE OrderId=@id", new SqlParameter("@id", id));
            }
            else
            {
                object newId = Db.Scalar(@"INSERT INTO OrderHeader(OrderDate, DeliveryDate, PickupPointId, CustomerName, ReceiveCode, OrderStatusId)
                                           OUTPUT INSERTED.OrderId
                                           VALUES(@orderDate, @deliveryDate, @pickup, @customer, @code, @status)", HeaderParams(code));
                id = Convert.ToInt32(newId);
            }

            foreach (Tuple<string, int> tuple in orderItems)
            {
                object itemId = Db.Scalar("SELECT ItemId FROM Item WHERE Article=@article", new SqlParameter("@article", tuple.Item1));
                if (itemId == null)
                {
                    MessageBox.Show("Артикул не найден: " + tuple.Item1, "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Db.Execute("INSERT INTO OrderItem(OrderId, ItemId, Quantity) VALUES(@orderId, @itemId, @qty)",
                    new SqlParameter("@orderId", id),
                    new SqlParameter("@itemId", Convert.ToInt32(itemId)),
                    new SqlParameter("@qty", tuple.Item2));
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private SqlParameter[] HeaderParams(int code, params SqlParameter[] extra)
        {
            List<SqlParameter> list = new List<SqlParameter>
            {
                new SqlParameter("@orderDate", dtOrderDate.Value.Date),
                new SqlParameter("@deliveryDate", dtDeliveryDate.Value.Date),
                new SqlParameter("@pickup", cmbPickupPoint.SelectedValue),
                new SqlParameter("@customer", txtCustomerName.Text.Trim()),
                new SqlParameter("@code", code),
                new SqlParameter("@status", cmbStatus.SelectedValue)
            };
            list.AddRange(extra);
            return list.ToArray();
        }

        private bool TryParseItems(out List<Tuple<string, int>> result)
        {
            result = new List<Tuple<string, int>>();
            string[] parts = txtArticles.Text.Split(',');
            if (parts.Length == 0 || parts.Length % 2 != 0)
            {
                MessageBox.Show("Введите пары: артикул, количество.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            for (int i = 0; i < parts.Length; i += 2)
            {
                int qty;
                string article = parts[i].Trim();
                if (string.IsNullOrWhiteSpace(article) || !int.TryParse(parts[i + 1].Trim(), out qty) || qty <= 0)
                {
                    MessageBox.Show("Проверьте артикулы и количества.", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
                result.Add(new Tuple<string, int>(article, qty));
            }

            return true;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
